iOS7-day-by-day
===============

This repo contains the sample projects which accompany a blog series which
takes a look at some of the new features available to developers in iOS7.
The blog series is available here:

http://www.shinobicontrols.com/blog/posts/2013/09/19/introducing-ios7-day-by-day/

If you have any suggestions / ideas / comments please feel free to catch me on
twitter at [@iwantmyrealname](https://twitter.com/iwantmyrealname), and do
fork the repo and have a play around with the code!

sam

[iwantmyreal.name](http://iwantmyreal.name/)

[@iwantmyreal.name](https://twitter.com/iwantmyrealname)

[ShinobiControls Blogs](http://www.shinobicontrols.com/blog/?author=sdavies)
