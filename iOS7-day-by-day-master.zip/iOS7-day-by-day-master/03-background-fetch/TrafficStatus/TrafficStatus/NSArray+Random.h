//
//  NSArray+Random.h
//  TrafficStatus
//
//  Created by Sam Davies on 09/07/2013.
//  Copyright (c) 2013 ShinobiControls. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Random)

- (id)randomElement;

@end
