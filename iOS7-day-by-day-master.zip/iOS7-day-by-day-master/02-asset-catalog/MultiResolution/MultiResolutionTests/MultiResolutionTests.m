//
//  MultiResolutionTests.m
//  MultiResolutionTests
//
//  Created by Sam Davies on 05/07/2013.
//  Copyright (c) 2013 ShinobiControls. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface MultiResolutionTests : XCTestCase

@end

@implementation MultiResolutionTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
