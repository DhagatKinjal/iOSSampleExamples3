//
//  NewtonsCradleTests.m
//  NewtonsCradleTests
//
//  Created by Sam Davies on 02/07/2013.
//  Copyright (c) 2013 ShinobiControls. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface NewtonsCradleTests : XCTestCase

@end

@implementation NewtonsCradleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
