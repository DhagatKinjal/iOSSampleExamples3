//
//  GreetingSpeakerTests.m
//  GreetingSpeakerTests
//
//  Created by Sam Davies on 12/07/2013.
//  Copyright (c) 2013 ShinobiControls. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface GreetingSpeakerTests : XCTestCase

@end

@implementation GreetingSpeakerTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
