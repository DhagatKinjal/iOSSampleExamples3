//
//  ViewController.h
//  ALAlertBannerDemo
//
//  Created by Anthony Lobianco on 8/12/13.
//  Copyright (c) 2013 Anthony Lobianco. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
