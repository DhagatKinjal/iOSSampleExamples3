//
//  AppDelegate.h
//  BatchUpdate
//
//  Created by Alex Burgel on 4/17/13.
//
//

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
