//
//  UILabel+Highlight.h
//  SelectionDelegateExample
//
//  Created by Eric Chen on 1/21/13.
//  Copyright (c) 2013 orta therox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Highlight)

@end
