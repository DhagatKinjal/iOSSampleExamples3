//
//  DecorationViewLayoutAttributes.h
//  PSCollectionViewExample
//
//  Created by Scott Talbot on 7/03/13.
//

#import "PSTCollectionView.h"

@interface DecorationViewLayoutAttributes : PSUICollectionViewLayoutAttributes

@property (nonatomic,strong) UIColor *backgroundColor;

@end
