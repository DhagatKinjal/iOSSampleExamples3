//
//  CollectionViewLayout.h
//  PSCollectionViewExample
//
//  Created by Scott Talbot on 7/03/13.
//

#import "PSTCollectionView.h"

@interface CollectionViewLayout : PSUICollectionViewFlowLayout

@end
