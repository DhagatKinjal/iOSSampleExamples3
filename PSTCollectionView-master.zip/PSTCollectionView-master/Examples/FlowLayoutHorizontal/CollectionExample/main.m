//
//  main.m
//  CollectionExample
//
//  Created by Barry Haanstra on 19-10-12.
//  Copyright (c) 2012 Haanstra. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
