//
//  FooterView.h
//  FlowLayoutNoNIB
//
//  Created by Beau G. Bolle on 2012.10.29.
//
//

#import "PSTCollectionView.h"

@interface FooterView : PSUICollectionReusableView

@end
