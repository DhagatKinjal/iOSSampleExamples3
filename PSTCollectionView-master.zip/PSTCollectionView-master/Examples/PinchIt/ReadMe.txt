### PinchIt ###

===========================================================================
DESCRIPTION:

Illustrates use of a flow layout subclass to pinch and move a cell.


===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.0
- First version.

===========================================================================
Copyright (C) 2012 Apple Inc. All rights reserved.
