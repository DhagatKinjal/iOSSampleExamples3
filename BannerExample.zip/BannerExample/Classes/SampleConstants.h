//
//  SampleConstants.h
//  BannerExample
//
//  Copyright 2011 Google Inc. All rights reserved.
//
//

// You should define this for your account before compiling.
// For AdMob, this is your site ID.
// For Ad Exchange, this is <google_ad_client>/<google_ad_slot>
#define kSampleAdUnitID @"ca-app-pub-1407798521272147/4327848915"
