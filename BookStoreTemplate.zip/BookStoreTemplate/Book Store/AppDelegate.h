//
//  AppDelegate.h
//  Book Store
//
//  Created by TAMIM Ziad on 9/6/13.
//  Copyright (c) 2013 TAMIM Ziad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
