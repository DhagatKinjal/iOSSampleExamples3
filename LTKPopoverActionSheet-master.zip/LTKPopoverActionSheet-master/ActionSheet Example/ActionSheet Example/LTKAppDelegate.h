//
//  LTKAppDelegate.h
//  ActionSheet Example
//
//  Created by Adam on 9/30/12.
//  Copyright (c) 2012 Logical Thought. All rights reserved.
//

#import <UIKit/UIKit.h>

@class LTKViewController;

@interface LTKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) LTKViewController *viewController;

@end
