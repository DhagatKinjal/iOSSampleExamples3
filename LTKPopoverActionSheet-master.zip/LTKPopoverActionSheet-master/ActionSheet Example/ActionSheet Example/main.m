//
//  main.m
//  ActionSheet Example
//
//  Created by Adam on 9/30/12.
//  Copyright (c) 2012 Logical Thought. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LTKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LTKAppDelegate class]));
    }
}
