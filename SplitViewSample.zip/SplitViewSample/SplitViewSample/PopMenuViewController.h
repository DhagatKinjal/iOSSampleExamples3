//
//  PopMenuViewController.h
//  SplitViewSample
//
//  Created by Jenn on 5/20/13.
//  Copyright (c) 2013 Jenn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PopMenuDetailViewController.h"

@interface PopMenuViewController : UITableViewController

@property (strong, nonatomic) PopMenuDetailViewController *detailViewController;

@end
