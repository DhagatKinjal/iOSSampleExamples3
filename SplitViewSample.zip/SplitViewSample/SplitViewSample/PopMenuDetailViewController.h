//
//  PopMenuDetailViewController.h
//  SplitViewSample
//
//  Created by Jenn on 5/20/13.
//  Copyright (c) 2013 Jenn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopMenuDetailViewController : UIViewController


- (void)updateMenuLabel:(NSString *)passedObject;

@end
