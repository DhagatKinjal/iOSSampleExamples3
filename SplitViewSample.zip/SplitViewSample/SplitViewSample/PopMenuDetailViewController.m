//
//  PopMenuDetailViewController.m
//  SplitViewSample
//
//  Created by Jenn on 5/20/13.
//  Copyright (c) 2013 Jenn. All rights reserved.
//

#import "PopMenuDetailViewController.h"

@interface PopMenuDetailViewController ()

@property (nonatomic, strong) IBOutlet UILabel *passedObjLabel;

@end

@implementation PopMenuDetailViewController

@synthesize passedObjLabel;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Detail";
    }
    return self;
}

- (void)updateMenuLabel:(NSString *)passedObject
{
    if (![self.passedObjLabel.text isEqualToString:passedObject]) {
        self.passedObjLabel.text = passedObject;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self updateMenuLabel:@"Menu 1"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
