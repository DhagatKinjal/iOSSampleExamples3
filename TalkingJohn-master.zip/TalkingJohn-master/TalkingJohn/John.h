//
//  John.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-3.
//  Copyright 2011年 盛大网络. All rights reserved.
//  

#import <Foundation/Foundation.h>
#import "cocos2d.h"

#define kJohnWidth  137
#define kJohnHeight 200

typedef enum
{
    AT_BLINK = 0,
    AT_LISTEN,
    AT_TALK
}JohnAnimationType;

@interface John : CCSprite <CCTargetedTouchDelegate>
{
    id blinkAction;
    id listenAction;
    id talkAction;
}

+ (id)john;

- (void)runAnimation:(JohnAnimationType)type;



@end
