//
//  RootViewController.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-3.
//  Copyright 盛大网络 2011年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <mediaplayer/mediaplayer.h>

@interface RootViewController : UIViewController {

}

@end
