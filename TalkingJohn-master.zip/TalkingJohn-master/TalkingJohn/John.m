//
//  John.m
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-3.
//  Copyright 2011年 盛大网络. All rights reserved.
//

#import "John.h"
#import "cocos2d.h"
#import "CCDirector+RecordScreen.h"

@implementation John

+ (id)john
{
    John *aJohn = [[[John alloc] initWithFile:@"john.png"] autorelease];
    aJohn.anchorPoint = ccp(0.5, 0.5);
    CGSize winSize = [[CCDirector sharedDirector] winSize];
    aJohn.position = ccp(winSize.width / 2, winSize.height / 2);
    return aJohn;
}

- (id)init
{
    self = [super init];
    if (self) {

    }
    
    return self;
}

- (void)dealloc
{
    [blinkAction release];
    [listenAction release];
    [talkAction release];
    [super dealloc];
}

- (CGRect)rect
{
	// NSLog([self description]);
	return CGRectMake(-rect_.size.width / 2, -rect_.size.height / 2, rect_.size.width, rect_.size.height);
}


- (void)runAnimation:(JohnAnimationType)type
{
    [self stopAllActions];
    CCAnimation *animation = nil;
    NSString *path = nil;
    switch (type) 
    {
        case AT_BLINK:
            if(blinkAction == nil)
            {
                animation = [CCAnimation animation];
                animation.name = @"blink";
                animation.delay = 0.2;
                path = [[NSBundle mainBundle] pathForResource:@"AnimationsBacteria/blink/bakterija pomezikne" ofType:@"png"]; 
                [animation addFrameWithFilename:path];
                for(int i = 0; i < 5; i++)
                {
                    [animation addFrameWithFilename:@"john.png"];
                }
                blinkAction = [[CCAnimate actionWithAnimation:animation] retain];
            }
            [self runAction:[CCRepeatForever actionWithAction:blinkAction]];
            break;
        case AT_LISTEN:
            if(listenAction == nil)
            {
                animation = [CCAnimation animation];
                animation.name = @"listen";
                animation.delay = 1;
                path = [[NSBundle mainBundle] pathForResource:@"AnimationsBacteria/listen/bakterija poslusa" ofType:@"png"]; 
                [animation addFrameWithFilename:path];
                listenAction = [[CCAnimate actionWithAnimation:animation] retain];
            }
            [self runAction:[CCRepeatForever actionWithAction:listenAction]];
            break;
        case AT_TALK:
            if(talkAction == nil)
            {
                animation = [CCAnimation animation];
                animation.name = @"talk";
                animation.delay = 0.008;
                for(int i = 0; i < 16; i++)
                {
                    NSString *filePath = [NSString stringWithFormat:@"AnimationsBacteria/talk/crazy_bacteria%04d", i];
                    path = [[NSBundle mainBundle] pathForResource:filePath ofType:@"png"]; 
                    [animation addFrameWithFilename:path];
                }
                for(int i = 14; i >= 1; i--)
                {
                    NSString *filePath = [NSString stringWithFormat:@"AnimationsBacteria/talk/crazy_bacteria%04d", i];
                    path = [[NSBundle mainBundle] pathForResource:filePath ofType:@"png"]; 
                    [animation addFrameWithFilename:path];
                }

                talkAction = [[CCAnimate actionWithAnimation:animation] retain];
            }
            
            [self runAction:[CCRepeatForever actionWithAction:talkAction]];          
        default:
            break;
    }
    
}

- (BOOL)hitTest:(UITouch *)touch
{
//	CGPoint pt = [self convertTouchToNodeSpaceAR:touch];
//	NSLog([NSString stringWithFormat:@"Rect x=%.2f, y=%.2f, width=%.2f, height=%.2f, Touch point: x=%.2f, y=%.2f", self.rect.origin.x, self.rect.origin.y, self.rect.size.width, self.rect.size.height, pt.x, pt.y]); 
//	
	return CGRectContainsPoint(self.rect, [self convertTouchToNodeSpaceAR:touch]);
}


- (void)onEnter
{
    [[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
    [super onEnter];    
}

- (void)onExit
{
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
    [super onExit];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    if(![self hitTest:touch])
        return NO;
 
	return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event
{

}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
}


@end
