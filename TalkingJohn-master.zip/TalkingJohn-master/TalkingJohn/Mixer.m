//
//  Mixer.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-9.
//  Copyright 2011年 盛大网络. All rights reserved.
//  封装dirac变音功能
//

#import "Mixer.h"
#import "GameScene.h"
#import "Dirac.h"
#import "GameConfig.h"
#import <sys/time.h>
#import <AVFoundation/AVAudioPlayer.h>
#import <AVFoundation/AVFoundation.h>

void DeallocateAudioBuffer(float **audio, int numChannels)
{
	if (!audio) return;
	for (long v = 0; v < numChannels; v++) {
		if (audio[v]) {
			free(audio[v]);
			audio[v] = NULL;
		}
	}
	free(audio);
	audio = NULL;
}

float **AllocateAudioBuffer(int numChannels, int numFrames)
{
	// Allocate buffer for output
	float **audio = (float**)malloc(numChannels*sizeof(float*));
	if (!audio) return NULL;
	memset(audio, 0, numChannels*sizeof(float*));
	for (long v = 0; v < numChannels; v++) {
		audio[v] = (float*)malloc(numFrames*sizeof(float));
		if (!audio[v]) {
			DeallocateAudioBuffer(audio, numChannels);
			return NULL;
		}
		else memset(audio[v], 0, numFrames*sizeof(float));
	}
	return audio;
}	

long myReadData(float **chdata, long numFrames, void *userData)
{	

	if (!chdata)	
        return 0;
	
	Mixer *mixer = (Mixer *)userData;
	if (!mixer)	return 0;

	OSStatus err = [mixer.reader readFloatsConsecutive:numFrames intoArray:chdata];
	
	DiracStartClock();	
    
	return err;
}

@implementation Mixer

@synthesize delegate;
@synthesize reader;
@synthesize writer;
@synthesize player;
@synthesize monitor;
@synthesize recorder;
@synthesize playbackUrl;
@synthesize recordUrl;

- (id)initWithLayer:(CCLayer *)layer
{
    self = [super init];
    if (self) {
        _layer = layer;
        [self initAudioMonitor];
        [self initAudioRecorder];
        [_layer schedule:@selector(monitorTimer:)];   
    }
    
    return self;
}

- (void)dealloc
{
    self.reader = nil;
    self.writer = nil;
    self.monitor = nil;
    self.player = nil;
    self.recorder = nil;
    self.playbackUrl = nil;
    self.recordUrl = nil;
    [super dealloc];

}

- (void)initAudioMonitor
{   
    NSMutableDictionary* recordSetting = [[[NSMutableDictionary alloc] init] autorelease];
    [recordSetting setValue :[NSNumber numberWithInt:kAudioFormatAppleIMA4] forKey:AVFormatIDKey];
    [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey]; 
    [recordSetting setValue:[NSNumber numberWithInt: 1] forKey:AVNumberOfChannelsKey];
    
    NSArray* documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);    
    NSString* fullFilePath = [[documentPaths objectAtIndex:0] stringByAppendingPathComponent: @"monitor.caf"];
    NSURL *tmpFile = [NSURL fileURLWithPath:fullFilePath];
    
    self.monitor = [[[AVAudioRecorder alloc] initWithURL: tmpFile settings:recordSetting error:nil] autorelease];
    
    [self.monitor setMeteringEnabled:YES];    
    [self.monitor prepareToRecord];
    [self.monitor record];
}

- (void)initAudioRecorder
{    
    NSMutableDictionary* recordSetting = [[[NSMutableDictionary alloc] init] autorelease];
    [recordSetting setValue :[NSNumber numberWithInt:kAudioFormatAppleIMA4] forKey:AVFormatIDKey];
    [recordSetting setValue:[NSNumber numberWithFloat:44100.0] forKey:AVSampleRateKey]; 
    [recordSetting setValue:[NSNumber numberWithInt: 1] forKey:AVNumberOfChannelsKey];
    
    NSArray* documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* fullFilePath = [[documentPaths objectAtIndex:0] stringByAppendingPathComponent:REC_AUDIO];
    self.recordUrl = [NSURL fileURLWithPath:fullFilePath];
    
    self.recorder = [[[AVAudioRecorder alloc] initWithURL: self.recordUrl settings:recordSetting error:nil] autorelease];    
    
    [self.recorder setMeteringEnabled:YES];    
    [self.recorder prepareToRecord];
}

- (void)playbackTimer:(ccTime)dt
{
    _playbackTime += dt;
    if(_playbackTime > (_recordingTime - MAX_SILENCETIME + (0.15 * _playbackTime)))
    {
        [self.player stop];
        _isPlaying = NO;
        _playbackTime = 0;
        [_layer unschedule:@selector(playbackTimer:)]; 
        [self.monitor record];
        [delegate endPlayback];
    }
}

- (void)monitorTimer:(ccTime)dt
{   
    if(_isPlaying)
        return;
    
    [self.monitor updateMeters];

    float avg = [self.monitor averagePowerForChannel:0];
    if (avg > MIN_AVERAGEPOWER)
    {   
        //NSLog(@"Sound detected");
        if(!_isRecording)
        {   
            [self.monitor stop];
            [self startRecording];
        }
        _silenceTime = 0;
    }  
    else
    {   
        //NSLog(@"Silence detected");
        if(_isRecording)
        {   
            _recordingTime += dt;
            [self.recorder updateMeters];
            avg = [self.recorder averagePowerForChannel:0];
            if (avg > MIN_AVERAGEPOWER)
            {
                _silenceTime = 0;
            }
            else
            {
                _silenceTime += dt;
                NSLog(@"%f -------%f \n", avg, _silenceTime);
                
                if(_silenceTime > MAX_SILENCETIME)
                {   
                    NSLog(@"Next silence detected");
                    [self stopRecordingAndPlay];
                    _silenceTime = 0;
                }   
            }
        }
    }

}

- (void)startRecording
{  
    NSLog(@"startRecording");
    _recordingTime = 0;    
    _isRecording = YES;
    [self.recorder record];
    [delegate startRecord];
}

- (void)stopRecordingAndPlay
{   
    NSLog(@"stopRecording Record time: %f", [self.recorder currentTime]);
    
    _isRecording = NO;
    [self.recorder stop];
    
    _isPlaying = YES;
    _playbackTime = 0;
    [_layer schedule:@selector(playbackTimer:)];
    
    [delegate startPlayback];
    [self initDiracPlayer];    
}

- (void)initDiracPlayer
{   
    NSString *outputSound = [[NSHomeDirectory() stringByAppendingString:@"/Documents/"] stringByAppendingString:MIXED_AUDIO];
	self.playbackUrl = [NSURL fileURLWithPath:outputSound];
	self.reader = [[[EAFRead alloc] init] autorelease];
	self.writer = [[[EAFWrite alloc] init] autorelease];
    
	// this thread does the processing
	[NSThread detachNewThreadSelector:@selector(processThread:) toTarget:self withObject:nil];
}

- (void)playOnMainThread:(id)param
{
	self.player = [[[AVAudioPlayer alloc] initWithContentsOfURL:self.playbackUrl error:nil] autorelease];    
	self.player.delegate = self;
	[self.player play];
}

- (void)processThread:(id)param
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
	long numChannels = 1;		// DIRAC LE allows mono only
	float sampleRate = 44100;
    
	// open input file
	[self.reader openFileForRead:self.recordUrl sr:sampleRate channels:numChannels];
	
	// create output file (overwrite if exists)
	[self.writer openFileForWrite:self.playbackUrl sr:sampleRate channels:numChannels wordLength:16 type:kAudioFileAIFFType];	
	
	// First we set up DIRAC to process numChannels of audio at 44.1kHz
	// N.b.: The fastest option is kDiracLambdaPreview / kDiracQualityPreview, best is kDiracLambda3, kDiracQualityBest
	// The probably best *default* option for general purpose signals is kDiracLambda3 / kDiracQualityGood
	void *dirac = DiracCreate(kDiracLambdaPreview, kDiracQualityPreview, numChannels, sampleRate, &myReadData, (void*)self);
	//	void *dirac = DiracCreate(kDiracLambda3, kDiracQualityBest, numChannels, sampleRate, &myReadData);
	if (!dirac) {
		printf("!! ERROR !!\n\n\tCould not create DIRAC instance\n\tCheck number of channels and sample rate!\n");
		printf("\n\tNote that the free DIRAC LE library supports only\n\tone channel per instance\n\n\n");
		exit(-1);
	}
	
	// Pass the values to our DIRAC instance 	
    
    float time      = 1;
    float pitch = powf(2.f, ((GameScene*)_layer).slider.value / 12.f);
    //float pitch     = 1.75;

	DiracSetProperty(kDiracPropertyTimeFactor, time, dirac);
	DiracSetProperty(kDiracPropertyPitchFactor, pitch, dirac);
    
	// upshifting pitch will be slower, so in this case we'll enable constant CPU pitch shifting
	if (pitch > 1.0)
		DiracSetProperty(kDiracPropertyUseConstantCpuPitchShift, 1, dirac);
    
	// Print our settings to the console
	//DiracPrintSettings(dirac);
	
	NSLog(@"Running DIRAC version %s\nStarting processing", DiracVersion());
	
	// Get the number of frames from the file to display our simplistic progress bar
	SInt64 numf = [self.reader fileNumFrames];
	SInt64 outframes = 0;
	SInt64 newOutframe = numf*time;
	long lastPercent = -1;
	float percent = 0;
	
	// This is an arbitrary number of frames per call. Change as you see fit
	long numFrames = 8192;
	
	// Allocate buffer for output
	float **audio = AllocateAudioBuffer(numChannels, numFrames);
    
	double bavg = 0;
	
	// MAIN PROCESSING LOOP STARTS HERE
	for(;;) {
		
		// Display ASCII style "progress bar"
		percent = 100.f*(double)outframes / (double)newOutframe;
		long ipercent = percent;
		if (lastPercent != percent) {
			/**
             printf("\rProgress: %3i%% [%-40s] ", ipercent, &"||||||||||||||||||||||||||||||||||||||||"[40 - ((ipercent>100)?40:(2*ipercent/5))] );
             **/
            lastPercent = ipercent;
			fflush(stdout);
		}
		
		DiracStartClock();								// ............................. start timer ..........................................
		
		// Call the DIRAC process function with current time and pitch settings
		// Returns: the number of frames in audio
		long ret = DiracProcess(audio, numFrames, dirac);
		bavg += (numFrames/sampleRate);
        /**
         printf("x realtime = %3.3f : 1 (DSP only), CPU load (peak, DSP+disk): %3.2f%%\n", bavg/gExecTimeTotal, DiracPeakCpuUsagePercent(dirac));
         **/
        
		// Process only as many frames as needed
		long framesToWrite = numFrames;
		unsigned long nextWrite = outframes + numFrames;
		if (nextWrite > newOutframe) framesToWrite = numFrames - nextWrite + newOutframe;
		if (framesToWrite < 0) framesToWrite = 0;
		
		// Write the data to the output file
		[self.writer writeFloats:framesToWrite fromArray:audio];
		
		// Increase our counter for the progress bar
		outframes += numFrames;
		
		// As soon as we've written enough frames we exit the main loop
		if (ret <= 0) break;
	}
	
	//percent = 100;
	
	// Free buffer for output
	DeallocateAudioBuffer(audio, numChannels);
	
	// destroy DIRAC instance
	DiracDestroy(dirac);
	
	// Done!
	NSLog(@"\nDone!");
	
	self.reader = nil;
	self.writer = nil; // important - flushes data to file
	
	// start playback on main thread
	[self performSelectorOnMainThread:@selector(playOnMainThread:) withObject:self waitUntilDone:NO];
	
	[pool release];
}

- (void)enable
{
    [_layer schedule:@selector(monitorTimer:)];
}

- (void)disable
{
    [_layer unschedule:@selector(monitorTimer:)];  
}

#pragma -
#pragma delegate methodes

//- (void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
//{   
//    _isPlaying = NO;
//    [self.monitor record];
//    [delegate endPlayback];
//}


@end
