//
//  CCDirector+RecordScreen.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-13.
//  Copyright 2011年 盛大网络. All rights reserved.
//  为cocos2d增加录制屏幕功能

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "cocos2d.h"

@interface CCDirector (CCDirector_RecordScreen)

NSTimer *clockTimer;
NSTimer *assetWriterTimer;
AVMutableComposition *mutableComposition;
AVAssetWriter *assetWriter;
AVAssetWriterInput *assetWriterInput;
AVAssetWriterInputPixelBufferAdaptor *assetWriterPixelBufferAdaptor;
CFAbsoluteTime firstFrameWallClockTime;

- (void)startRecording;
- (void)stopRecording;
- (UIImage*)screenShotUIImage;
- (NSString*)pathToDocumentsDirectory;
- (BOOL)compositeAVWithStartVideo:(NSDate *)startVideo startAudio:(NSDate *)startAudio endAudio:(NSDate *)endAudio;

@end
