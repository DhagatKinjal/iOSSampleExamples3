//
//  GameScene.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-3.
//  Copyright 2011年 盛大网络. All rights reserved.
//  主游戏场景
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "Mixer.h"
#import "John.h"

@class MPMoviePlayerViewController;

@interface GameScene : CCLayer <MixerDelegate, UIActionSheetDelegate>
{
    John *_john;
    UISlider *_slider;
    BOOL isRecordingScreen;
    UIButton *_recBtn;
    MPMoviePlayerViewController *_playerViewController;
    BOOL _compositeSuccess;
}

@property(nonatomic, retain) Mixer *mixer;
@property(nonatomic, readonly) UISlider *slider;
@property(nonatomic, retain) NSDate *startRecordScreenTime;
@property(nonatomic, retain) NSDate *startPlaybackAudioTime;
@property(nonatomic, retain) NSDate *endPlaybackAudioTime;

+ (id)scene;
- (void)monitorTimer:(ccTime)dt;
- (void)playbackTimer:(ccTime)dt;
- (void)startPlaybackRecordScreen;

@end
