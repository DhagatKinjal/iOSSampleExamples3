//
//  GameScene.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-3.
//  Copyright 2011年 盛大网络. All rights reserved.
//  主游戏场景
//

#import "AppDelegate.h"
#import "GameScene.h"
#import "John.h"
#import "CCDirector+RecordScreen.h"
#import "RootViewController.h"
#import "GameConfig.h"


@implementation GameScene

@synthesize mixer;
@synthesize slider = _slider;
@synthesize startRecordScreenTime;
@synthesize startPlaybackAudioTime;
@synthesize endPlaybackAudioTime;

- (id)init
{
    self = [super init];
    if (self) {
        
        self.startRecordScreenTime = [NSDate date]; 
        self.startPlaybackAudioTime = [NSDate date];
        self.endPlaybackAudioTime = [NSDate date];
        
        self.isTouchEnabled = YES;
        CCSprite *bg = [CCSprite spriteWithFile:@"Blood-membrane-iPhone.png"];
        bg.anchorPoint = ccp(0.5, 0.5);
        CGSize winSize = [[CCDirector sharedDirector] winSize];
        bg.position = ccp(winSize.width / 2, winSize.height / 2);
        [self addChild:bg z:0 tag:0];       
        _john = [John john];
        [self addChild:_john z:1 tag:1];
        
        self.mixer = [[[Mixer alloc] initWithLayer:self] autorelease];
        self.mixer.delegate = self;
        [_john runAnimation:AT_BLINK];
        
        CGRect rc = CGRectMake(100, 20, 180, 40);
        _slider = [[[UISlider alloc] initWithFrame:rc] autorelease];
        [_slider setMaximumValue:12];
        [_slider setMinimumValue:-12];
        [_slider setValue:6];
        [[[CCDirector sharedDirector] openGLView] addSubview:_slider];  
        
        _recBtn = [[[UIButton alloc] initWithFrame:CGRectMake(10, 10, 60, 60)] autorelease];
        [_recBtn setBackgroundImage:[UIImage imageNamed:@"RecButton0"] forState:UIControlStateNormal];
        [_recBtn addTarget:self action:@selector(recScreen:) forControlEvents:UIControlEventTouchUpInside];
        [[[CCDirector sharedDirector] openGLView] addSubview:_recBtn];  
        isRecordingScreen = NO;
        
    }
    return self;
}

- (void)dealloc
{
    self.mixer = nil;
    self.startPlaybackAudioTime = nil;
    self.startRecordScreenTime = nil;
    self.endPlaybackAudioTime = nil;
    [super dealloc];
}

+ (id)scene
{
    CCScene *scene = [CCScene node];
    GameScene *layer = [GameScene node];
    [scene addChild: layer];
    return scene;
}

- (void)monitorTimer: (ccTime) dt
{
    [self.mixer monitorTimer:dt];
}

- (void)playbackTimer:(ccTime)dt
{
    [self.mixer playbackTimer:dt];
}

- (void)blinkRecBtnTimer:(ccTime)dt
{
    static int blinkTimes = 0;
    [_recBtn setBackgroundImage:[UIImage imageNamed:(blinkTimes % 2 == 0) ? @"RecButton3" : @"RecButton2"] 
                                           forState:UIControlStateNormal];    
    blinkTimes++;
}

- (void)compositeAV
{
    _compositeSuccess = [[CCDirector sharedDirector] compositeAVWithStartVideo:self.startRecordScreenTime 
                                                startAudio:self.startPlaybackAudioTime 
                                                  endAudio:self.endPlaybackAudioTime];  
}

- (void)recScreen:(id)sender
{
    if(isRecordingScreen)
    {
        [self unschedule:@selector(blinkRecBtnTimer:)];
        [self.mixer disable];
        isRecordingScreen = NO;
        [_recBtn setBackgroundImage:[UIImage imageNamed:@"RecButton0"] forState:UIControlStateNormal];
        [[CCDirector sharedDirector] stopRecording];
        
        //[self performSelector:@selector(compositeAV) withObject:nil afterDelay:10];
        [self compositeAV];
        UIActionSheet *actionSheet = [[UIActionSheet alloc] 
                                      initWithTitle:@""
                                      delegate:self 
                                      cancelButtonTitle:@"Cancel" 
                                      destructiveButtonTitle:@"Play" 
                                      otherButtonTitles:@"Upload to youtube(to do ...)", nil];
        
        [actionSheet showInView:[[CCDirector sharedDirector] openGLView]];
        [actionSheet release];
    }
    else
    {
        isRecordingScreen = YES;
        self.startRecordScreenTime = [NSDate date];
        [[CCDirector sharedDirector] startRecording];
        [self schedule:@selector(blinkRecBtnTimer:) interval:0.5f];
    }
}

- (void) movieFinishedCallback:(NSNotification*) aNotification {  
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    [(RootViewController*)[appDelegate getRootViewController] dismissMoviePlayerViewControllerAnimated];
    //[_playerViewController.view removeFromSuperview];
    [self.mixer enable];
    [_playerViewController release];
}

- (void)startPlaybackRecordScreen
{
    if(!_compositeSuccess)
        return;
    
    NSString *moviePath = [[[CCDirector sharedDirector] pathToDocumentsDirectory] stringByAppendingPathComponent:COMPOSITE_VIDEO];
    _playerViewController = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL fileURLWithPath:moviePath]];  
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(movieFinishedCallback:)  
                                                 name:MPMoviePlayerPlaybackDidFinishNotification  
                                               object:nil];  
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    [(RootViewController*)[appDelegate getRootViewController] presentMoviePlayerViewControllerAnimated:_playerViewController];
    //[[[CCDirector sharedDirector] openGLView] addSubview:_playerViewController.view];
    _playerViewController.moviePlayer.movieSourceType = MPMovieSourceTypeFile;
    
    [_playerViewController.moviePlayer play]; 
}

#pragma -

- (void)startRecord
{
    [_john runAnimation:AT_LISTEN];
}

- (void)endRecode
{
    
}

- (void)startPlayback
{
    [_john runAnimation:AT_TALK];
    _recBtn.enabled = NO;
    self.startPlaybackAudioTime = [NSDate date];
}

- (void)endPlayback
{
    [_john runAnimation:AT_BLINK];
    _recBtn.enabled = YES;
    self.endPlaybackAudioTime = [NSDate date];
}

#pragma mark ActionSheet Delegate Methods

- (void) actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    
    if (buttonIndex == [actionSheet destructiveButtonIndex])
    {
        [self startPlaybackRecordScreen]; 
    }
    else
    {
        [self.mixer enable];
    }
}

@end
