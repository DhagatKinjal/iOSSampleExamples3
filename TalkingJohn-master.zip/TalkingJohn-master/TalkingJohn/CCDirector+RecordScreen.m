//
//  CCDirector+RecordScreen.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-13.
//  Copyright 2011年 盛大网络. All rights reserved.
//  为cocos2d增加录制屏幕功能

#import "CCDirector+RecordScreen.h"
#import "GameConfig.h"

#pragma mark screenshot
// copied from http://www.cocos2d-iphone.org/forum/topic/1722 

@implementation CCDirector (CCDirector_RecordScreen)

- (void)dealloc {
    [clockTimer invalidate]; clockTimer = nil;
	[assetWriterTimer invalidate]; assetWriterTimer = nil;
	[assetWriter release]; assetWriter = nil;
	[assetWriterInput release]; assetWriterInput = nil;
	[assetWriterPixelBufferAdaptor release]; assetWriterPixelBufferAdaptor = nil;
    [super dealloc];
}

#pragma mark helpers
-(NSString*) pathToDocumentsDirectory {
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	NSString *documentsDirectory = [paths objectAtIndex:0];
	return documentsDirectory;
}

-(void) writeSample: (NSTimer*) _timer {
	if (assetWriterInput.readyForMoreMediaData) {
		// CMSampleBufferRef sample = nil;
        
		CVReturn cvErr = kCVReturnSuccess;
        
		// get screenshot image!
		CGImageRef image = (CGImageRef) [[self screenShotUIImage] CGImage];
		NSLog (@"made screenshot");
		
		// prepare the pixel buffer
		CVPixelBufferRef pixelBuffer = NULL;
		CFDataRef imageData= CGDataProviderCopyData(CGImageGetDataProvider(image));
		NSLog (@"copied image data");
		cvErr = CVPixelBufferCreateWithBytes(kCFAllocatorDefault,
											 self.winSize.width,
											 self.winSize.height,
											 kCVPixelFormatType_32ARGB,
											 (void*)CFDataGetBytePtr(imageData),
											 CGImageGetBytesPerRow(image),
											 NULL,
											 NULL,
											 NULL,
											 &pixelBuffer);
		NSLog (@"CVPixelBufferCreateWithBytes returned %d", cvErr);
        
		// calculate the time
		CFAbsoluteTime thisFrameWallClockTime = CFAbsoluteTimeGetCurrent();
		CFTimeInterval elapsedTime = thisFrameWallClockTime - firstFrameWallClockTime;
		NSLog (@"elapsedTime: %f", elapsedTime);
		CMTime presentationTime =  CMTimeMake (elapsedTime * TIME_SCALE, TIME_SCALE);
		
		// write the sample
		BOOL appended = [assetWriterPixelBufferAdaptor appendPixelBuffer:pixelBuffer withPresentationTime:presentationTime];
        
		if (appended) {
			NSLog (@"appended sample at time %lf", CMTimeGetSeconds(presentationTime));
		} else {
			NSLog (@"failed to append");
			[self stopRecording];
		}
	}
}

-(void) startRecording {
	// create the AVAssetWriter
	NSString *moviePath = [[self pathToDocumentsDirectory] stringByAppendingPathComponent:REC_VIDEO];
	if ([[NSFileManager defaultManager] fileExistsAtPath:moviePath]) {
		[[NSFileManager defaultManager] removeItemAtPath:moviePath error:nil];
	}
	
	NSURL *movieURL = [NSURL fileURLWithPath:moviePath];
	NSError *movieError = nil;
	[assetWriter release];
	assetWriter = [[AVAssetWriter alloc] initWithURL:movieURL 
                                            fileType: AVFileTypeQuickTimeMovie 
                                               error: &movieError];
	NSDictionary *assetWriterInputSettings = [NSDictionary dictionaryWithObjectsAndKeys:
											  AVVideoCodecH264, AVVideoCodecKey,
											  [NSNumber numberWithInt:self.winSize.width], AVVideoWidthKey,
											  [NSNumber numberWithInt:self.winSize.height], AVVideoHeightKey,
											  nil];
	assetWriterInput = [AVAssetWriterInput assetWriterInputWithMediaType: AVMediaTypeVideo
														  outputSettings:assetWriterInputSettings];
	assetWriterInput.expectsMediaDataInRealTime = YES;
	[assetWriter addInput:assetWriterInput];
	
	[assetWriterPixelBufferAdaptor release];
	assetWriterPixelBufferAdaptor = [[AVAssetWriterInputPixelBufferAdaptor  alloc]
									 initWithAssetWriterInput:assetWriterInput
									 sourcePixelBufferAttributes:nil];
	[assetWriter startWriting];
	
	firstFrameWallClockTime = CFAbsoluteTimeGetCurrent();
	[assetWriter startSessionAtSourceTime: CMTimeMake(0, TIME_SCALE)];
	
	// start writing samples to it
	[assetWriterTimer release];
	assetWriterTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
														target:self
													  selector:@selector (writeSample:)
													  userInfo:nil
													   repeats:YES] ;
	
}

-(void) stopRecording {
	[assetWriterTimer invalidate];
	assetWriterTimer = nil;
	
	[assetWriter finishWriting];
    [assetWriter release];
    assetWriter = nil;
    [assetWriterPixelBufferAdaptor release];
    assetWriterPixelBufferAdaptor = nil;
	NSLog (@"finished writing");
}

- (UIImage*) screenShotUIImage {
    
	CGSize size = self.displaySizeInPixels;
    
	//Create buffer for pixels
	GLuint bufferLength = size.width * size.height * 4;
	GLubyte* buffer = (GLubyte*)malloc(bufferLength);
    
	//Read Pixels from OpenGL
	glReadPixels(0, 0, size.width, size.height, GL_RGBA, GL_UNSIGNED_BYTE, buffer);
	//Make data provider with data.
	CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, buffer, bufferLength, NULL);
    
	//Configure image
	int bitsPerComponent = 8;
	int bitsPerPixel = 32;
	int bytesPerRow = 4 * size.width;
	CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
	CGBitmapInfo bitmapInfo = kCGBitmapByteOrderDefault;
	CGColorRenderingIntent renderingIntent = kCGRenderingIntentDefault;
	CGImageRef iref = CGImageCreate(size.width, size.height, bitsPerComponent, bitsPerPixel, bytesPerRow, colorSpaceRef, bitmapInfo, provider, NULL, NO, renderingIntent);
    
	uint32_t* pixels = (uint32_t*)malloc(bufferLength);
	CGContextRef context = CGBitmapContextCreate(pixels, [self winSize].width, [self winSize].height, 8, [self winSize].width * 4, CGImageGetColorSpace(iref), kCGImageAlphaPremultipliedFirst | kCGBitmapByteOrder32Big);
    
	CGContextTranslateCTM(context, 0, size.height);
	CGContextScaleCTM(context, 1.0f, -1.0f);
    
	switch (self.deviceOrientation)
	{
		case CCDeviceOrientationPortrait:
			break;
		case CCDeviceOrientationPortraitUpsideDown:
			CGContextRotateCTM(context, CC_DEGREES_TO_RADIANS(180));
			CGContextTranslateCTM(context, -size.width, -size.height);
			break;
		case CCDeviceOrientationLandscapeLeft:
			CGContextRotateCTM(context, CC_DEGREES_TO_RADIANS(-90));
			CGContextTranslateCTM(context, -size.height, 0);
			break;
		case CCDeviceOrientationLandscapeRight:
			CGContextRotateCTM(context, CC_DEGREES_TO_RADIANS(90));
			CGContextTranslateCTM(context, size.width * 0.5f, -size.height);
			break;
	}
    
	CGContextDrawImage(context, CGRectMake(0.0f, 0.0f, size.width, size.height), iref);
	UIImage *outputImage = [UIImage imageWithCGImage:CGBitmapContextCreateImage(context)];
    
	//Dealloc
	CGDataProviderRelease(provider);
    CGColorSpaceRelease(colorSpaceRef);
	CGImageRelease(iref);
	CGContextRelease(context);
	free(buffer);
	free(pixels);
    
	return outputImage;
}

- (BOOL)compositeAVWithStartVideo:(NSDate *)startVideo startAudio:(NSDate *)startAudio endAudio:(NSDate *)endAudio
{
    NSString *moviePath = [[self pathToDocumentsDirectory] stringByAppendingPathComponent:REC_VIDEO];
    NSURL *videoUrl = [NSURL fileURLWithPath:moviePath];
    
    NSString *audioPath = [[self pathToDocumentsDirectory] stringByAppendingPathComponent:MIXED_AUDIO];
    NSURL *audioUrl = [NSURL fileURLWithPath:audioPath];
    

    AVURLAsset* videoAsset = [[AVURLAsset alloc]initWithURL:videoUrl options:nil];
    if([[videoAsset tracksWithMediaType:AVMediaTypeVideo] count] == 0)
        return NO;
    
    AVURLAsset* audioAsset = [[AVURLAsset alloc]initWithURL:audioUrl options:nil];
    AVMutableComposition* mixComposition = [AVMutableComposition composition];
    
    AVMutableCompositionTrack *compositionVideoTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeVideo 
                                                                                   preferredTrackID:kCMPersistentTrackID_Invalid];
    [compositionVideoTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, videoAsset.duration) 
                                   ofTrack:[[videoAsset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0] 
                                    atTime:kCMTimeZero error:nil];
    
    CFTimeInterval timeInterval = [startAudio timeIntervalSinceDate:startVideo];
    CMTime starAudioTime =  CMTimeMake (timeInterval * TIME_SCALE, TIME_SCALE); 
    
//    timeInterval = [endAudio timeIntervalSinceDate:startAudio];    
//    CMTime elapsedAudioTime =  CMTimeMake (timeInterval * TIME_SCALE, TIME_SCALE);

    AVMutableCompositionTrack *compositionCommentaryTrack = [mixComposition addMutableTrackWithMediaType:AVMediaTypeAudio 
                                                                                    preferredTrackID:kCMPersistentTrackID_Invalid];
    [compositionCommentaryTrack insertTimeRange:CMTimeRangeMake(kCMTimeZero, audioAsset.duration) 
                                    ofTrack:[[audioAsset tracksWithMediaType:AVMediaTypeAudio] objectAtIndex:0] 
                                     atTime:starAudioTime error:nil];

    AVAssetExportSession* _assetExport = [[AVAssetExportSession alloc] initWithAsset:mixComposition 
                                                                      presetName:AVAssetExportPresetPassthrough];   

    NSString *exportPath = [[self pathToDocumentsDirectory] stringByAppendingPathComponent:COMPOSITE_VIDEO];
    NSURL    *exportUrl = [NSURL fileURLWithPath:exportPath];

    if([[NSFileManager defaultManager] fileExistsAtPath:exportPath]) 
    {
        [[NSFileManager defaultManager] removeItemAtPath:exportPath error:nil];
    }

    _assetExport.outputFileType = @"com.apple.quicktime-movie";
    NSLog(@"file type %@",_assetExport.outputFileType);
    _assetExport.outputURL = exportUrl;
    _assetExport.shouldOptimizeForNetworkUse = YES;

    [_assetExport exportAsynchronouslyWithCompletionHandler:
     ^(void ) {      
         // your completion code here
     }];
    return YES;
}

@end
