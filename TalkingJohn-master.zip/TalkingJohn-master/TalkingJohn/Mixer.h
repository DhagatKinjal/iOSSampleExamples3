//
//  Mixer.h
//  TalkingJohn
//
//  Created by dingjie(007687)SDL on 11-11-9.
//  Copyright 2011年 盛大网络. All rights reserved.
//  封装dirac变音功能
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreAudio/CoreAudioTypes.h>
#import "cocos2d.h"
#import "EAFRead.h"
#import "EAFWrite.h"

@protocol MixerDelegate <NSObject>
- (void)startRecord;
- (void)endRecode;
- (void)startPlayback;
- (void)endPlayback;
@end

@interface Mixer : NSObject <AVAudioPlayerDelegate>
{
    CCLayer *_layer;
    BOOL _isRecording;
    BOOL _isPlaying;    
    float _silenceTime;	
    float _recordingTime;
    float _playbackTime;
}

@property(retain) EAFRead *reader;
@property(retain) EAFWrite *writer;
@property(assign) id<MixerDelegate> delegate;
@property(retain) AVAudioRecorder *recorder;
@property(retain) AVAudioRecorder *monitor;
@property(retain) AVAudioPlayer *player;
@property(retain) NSURL *recordUrl;
@property(retain) NSURL *playbackUrl;

- (id)initWithLayer:(CCLayer *)layer;
- (void)initAudioMonitor;
- (void)initAudioRecorder;
- (void)monitorTimer:(ccTime)dt;
- (void)playbackTimer:(ccTime)dt;
- (void)startRecording;
- (void)stopRecordingAndPlay;
- (void)initDiracPlayer;
- (void)playOnMainThread:(id)param;
- (void)processThread:(id)param;
- (void)enable;
- (void)disable;

@end
