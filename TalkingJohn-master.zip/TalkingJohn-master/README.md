TalkingJohn
===========

like talking tom cat