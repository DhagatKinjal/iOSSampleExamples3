//
//  RootViewController.h
//  AlertsDemo
//
//  Created by Adam Barrett on 13-04-02.
//  Copyright (c) 2013 progenius, inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController

@end
