
#import <UIKit/UIKit.h>

@interface UIView (Autolayout)
+ (id)newForAutolayoutAndAddToView:(UIView*)view;
@end
