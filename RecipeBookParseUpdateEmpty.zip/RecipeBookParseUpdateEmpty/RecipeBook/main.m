//
//  main.m
//  RecipeBook
//
//  Created by Simon Ng on 26/7/13.
//  Copyright (c) 2012 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RecipeBookAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RecipeBookAppDelegate class]));
    }
}
