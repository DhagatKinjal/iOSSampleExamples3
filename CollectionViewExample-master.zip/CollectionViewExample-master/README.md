CollectionViewExample
=====================

This is a simple example of how to create and customize a `UICollectionView`.  It's the source code to accompany the tutorial at [http://adoptioncurve.net/archives/2012/09/a-simple-uicollectionview-tutorial/](http://adoptioncurve.net/archives/2012/09/a-simple-uicollectionview-tutorial/)
