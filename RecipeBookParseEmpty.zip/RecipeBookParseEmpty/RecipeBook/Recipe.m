//
//  Recipe.m
//  RecipeBook
//
//  Created by Simon on 12/8/12.
//
//

#import "Recipe.h"

@implementation Recipe

@synthesize name;
@synthesize prepTime;
@synthesize imageFile;
@synthesize ingredients;

@end
