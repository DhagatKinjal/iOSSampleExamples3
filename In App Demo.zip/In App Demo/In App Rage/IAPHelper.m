//
//  IAPHelper.m
//  In App Rage
//
//  Created by Ray Wenderlich on 9/5/12.
//  Copyright (c) 2012 Razeware LLC. All rights reserved.
//

// 1
#import "IAPHelper.h"
#import <StoreKit/StoreKit.h>
#define kDownloadCounterTag 410

NSString *const IAPHelperProductPurchasedNotification = @"IAPHelperProductPurchasedNotification";
NSString *const IAPHelperProductCancelledNotification = @"IAPHelperProductCancelledNotification";
NSString *const IAPHelperProductStartedPurchaseNotification = @"IAPHelperProductStartedPurchaseNotification"; 
// 2
@interface IAPHelper () <SKProductsRequestDelegate, SKPaymentTransactionObserver>
@end

// 3
@implementation IAPHelper {
    SKProductsRequest * _productsRequest;
    RequestProductsCompletionHandler _completionHandler;
    
    UIAlertView *progressAlert;
    UIProgressView *progressView;

    NSSet * _productIdentifiers;
    NSMutableSet * _purchasedProductIdentifiers;
}

- (id)initWithProductIdentifiers:(NSSet *)productIdentifiers {
    
    if ((self = [super init])) {
        
        // Store product identifiers
        _productIdentifiers = productIdentifiers;
        
        // Check for previously purchased products
        _purchasedProductIdentifiers = [NSMutableSet set];
        for (NSString * productIdentifier in _productIdentifiers) {
            BOOL productPurchased = [[NSUserDefaults standardUserDefaults] boolForKey:productIdentifier];
            if (productPurchased) {
                [_purchasedProductIdentifiers addObject:productIdentifier];
                NSLog(@"Previously purchased: %@", productIdentifier);
            } else {
                NSLog(@"Not purchased: %@", productIdentifier);
            }
        }
        
        // Add self as transaction observer
        [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
        
    }
    return self;
    
}

- (void)requestProductsWithCompletionHandler:(RequestProductsCompletionHandler)completionHandler {
    
    
    // 1
    _completionHandler = [completionHandler copy];
    
    // 2
    _productsRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:_productIdentifiers];
    _productsRequest.delegate = self;
    [_productsRequest start];
    
}

- (BOOL)productPurchased:(NSString *)productIdentifier {
    return [_purchasedProductIdentifiers containsObject:productIdentifier];
}

- (void)buyProduct:(SKProduct *)product {
    
    NSLog(@"Buying %@...", product.productIdentifier);
    
    SKPayment * payment = [SKPayment paymentWithProduct:product];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
    
}

#pragma mark - SKProductsRequestDelegate

- (void)createProgressionAlertWithMessage:(NSString *)message {
    
    progressAlert = [[UIAlertView alloc] initWithTitle:message message:@"Please wait..." delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    
    // Create the progress bar and add it to the alert
    progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(30.0f, 80.0f, 225.0f, 90.0f)];
    [progressAlert addSubview:progressView];
    [progressView setProgressViewStyle:UIProgressViewStyleDefault];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(90.0f, 90.0f, 225.0f, 40.0f)];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:12.0f];
    label.text = @"";
    label.tag = kDownloadCounterTag;
    [progressAlert addSubview:label];
    
    [progressAlert show];
//    [progressAlert release];
}

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response {
    
    NSLog(@"Loaded list of products...");
    _productsRequest = nil;
    
    NSArray * skProducts = response.products;
    for (SKProduct * skProduct in skProducts)
    {
        NSLog(@"###########################################");
        //        NSLog(@"THE Product price is ::::::::%@",skProduct.price);
        //        NSLog(@"THE Product description is ::::::::%@",skProduct.localizedDescription);
        //        NSLog(@"THE Product title is ::::::::%@",skProduct.localizedTitle);
        NSLog(@"THE Product's product identifier is ::::::::%@",skProduct.productIdentifier);
        NSLog(@"LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL");
    }
    
    _completionHandler(YES, skProducts);
    _completionHandler = nil;
    
}

- (void)request:(SKRequest *)request didFailWithError:(NSError *)error {
    
    NSLog(@"Failed to load list of products.");
    _productsRequest = nil;
    
    _completionHandler(NO, nil);
    _completionHandler = nil;
    
}

#pragma mark SKPaymentTransactionOBserver

- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction * transaction in transactions) {
        switch (transaction.transactionState) {
            case SKPaymentTransactionStatePurchased:
                
                [[NSNotificationCenter defaultCenter] postNotificationName: IAPHelperProductStartedPurchaseNotification object:transaction.payment.productIdentifier userInfo:nil];
                
                if (transaction.downloads)
                {
                    [self createProgressionAlertWithMessage:@"Donwnloading"];
                    [[SKPaymentQueue defaultQueue]
                     startDownloads:transaction.downloads];
                } else {
                    // Unlock feature or content here before finishing
                    // transaction
                    //                    [[SKPaymentQueue defaultQueue]
                    //                     finishTransaction:transaction];
                    [self completeTransaction:transaction];
                    NSLog(@"Called finishTransaction after purchase");
                    
                }
                break;
                
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
                
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
                
            default:
                break;
        }
    }
}

//-(NSString*)getPDFFileName:(NSString *)pathName
//{
//    NSArray *arrayPaths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask,YES);
//    NSString *path = [arrayPaths objectAtIndex:0];
//
//    // Unzipping
//    NSString *zipPath = [NSString stringWithFormat:@"%@",pathName];
//    NSString *destinationPath = path;
//    [SSZipArchive unzipFileAtPath:zipPath toDestination:destinationPath];
//
//    NSString* pdfFileName = [path stringByAppendingPathComponent:@"Test.PDF"];
//
//
//    return pdfFileName;
//
//}

//- (void) processDownload:(SKDownload*)download;
//{
//    // convert url to string, suitable for NSFileManager
//    NSString *path = [download.contentURL path];
//    
//    // files are in Contents directory
//    path = [path stringByAppendingPathComponent:@"Contents"];
//    
//    NSFileManager *fileManager = [NSFileManager defaultManager];
//    NSError *error = nil;
//    NSArray *files = [fileManager contentsOfDirectoryAtPath:path error:&error];
//   // NSString *dir = [MyConfig downloadableContentPathForProductId:download.contentIdentifier]; // not written yet
//    
//    for (NSString *file in files) {
//        NSString *fullPathSrc = [path stringByAppendingPathComponent:file];
//        NSString *fullPathDst = [dir stringByAppendingPathComponent:file];
//        
//        // not allowed to overwrite files - remove destination file
//        [fileManager removeItemAtPath:fullPathDst error:NULL];
//        
//        if ([fileManager moveItemAtPath:fullPathSrc toPath:fullPathDst error:&error] == NO) {
//            NSLog(@"Error: unable to move item: %@", error);
//        }
//        
//        // 1st Code
//        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
//        NSString *documentsDirectory = [[paths objectAtIndex:0] string];
//        NSString *myPathDocs;
//        
//        myPathDocs =  [documentsDirectory stringByAppendingPathComponent:@"iaphostapril.pdf"];
//        NSURL *pdfURL = [NSURL fileURLWithPath:myPathDocs];
//        NSLog(@"myString %@",myPathDocs);
//        
//        
//        // 2nd Code
//        NSArray *pathing = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory,
//                                                               NSUserDomainMask,
//                                                               YES);
//        
//        NSString *fullPath = [[paths lastObject] stringByAppendingPathComponent:@"iaphostapril.pdf"];
//        
//        // 3rd Code
//        NSArray *path3 = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
//        NSString *documentsDirectory3 = [path3 objectAtIndex:0];
//        
//        NSFileManager *fileManager = [NSFileManager defaultManager];
//        NSError *error = nil;
//        NSArray *filesAtPath = [fileManager contentsOfDirectoryAtPath:documentsDirectory3 error:&error];
//        
//        for (NSString *path in filesAtPath)
//        {
//            if([filesAtPath containsObject:@"Application Support"])
//            {
//                
//            }
//            //            if ([path rangeOfString:@".pdf"].length > 0)
//            //            {
//            //                //Do whatever you want with the pdf file
//            //                NSLog(@"%@",path);
//            //            }
//        }
//        
//        // 4th Code
//        NSArray *path4 = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
//        NSString *documentsDirectory4 = [path4 objectAtIndex:0];
//        NSString *filePath = [documentsDirectory4 stringByAppendingPathComponent:@"iaphostapril.pdf"];
//        
//        NSURL *targetURL = [NSURL fileURLWithPath:filePath];
//        NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
//        
//        //5th code
//        
//    }
//}

- (void)paymentQueue:(SKPaymentQueue *)queue updatedDownloads:(NSArray *)downloads;
{
    for (SKDownload *download in downloads) {
        
        if (download.downloadState == SKDownloadStateFinished) {
            
           // [self processDownload:download];
            
            // now we're done
            [self provideContentForProductIdentifier:download.transaction.payment.productIdentifier];
            
            [progressAlert dismissWithClickedButtonIndex:0 animated:YES];
            
            [queue finishTransaction:download.transaction];
            
        } else if (download.downloadState == SKDownloadStateActive) {
            
            NSString *productID = download.contentIdentifier; // in app purchase identifier
            NSLog(@"%@",productID);
            
            NSTimeInterval remaining = download.timeRemaining; // secs
            NSLog(@"Download Remaing Time %f",remaining);
            
            float progress = download.progress; // 0.0 -> 1.0
            NSLog(@"Download Progress Time %.2f",progress);
            
            //            [[NSNotificationCenter defaultCenter] postNotificationName:IAPHelperProductStartedDownloadNotification object:downloads userInfo:nil];
            
            progressView.progress = progress;
            
            UILabel *label = (UILabel *)[progressAlert viewWithTag:kDownloadCounterTag];
            
            if(download.timeRemaining>60)
                label.text = [NSString stringWithFormat:@"Time Remaining %.2f minutes",download.timeRemaining/60.0];
            else
                label.text = [NSString stringWithFormat:@"Time Remaining %.2f seconds",download.timeRemaining];
            
        } else {    // waiting, paused, failed, cancelled
            NSLog(@"Warn: not handled: %d", download.downloadState);
            [progressAlert dismissWithClickedButtonIndex:0 animated:YES];
        }
    }
}

- (void)completeTransaction:(SKPaymentTransaction *)transaction {
    NSLog(@"completeTransaction...");
    
    NSData *receiptData = [NSData dataWithData:transaction.transactionReceipt];
    // This is the string you should pass to server for verification
    NSString *receiptStr = [[NSString alloc] initWithData:receiptData encoding:NSUTF8StringEncoding];
    
    [self provideContentForProductIdentifier:transaction.payment.productIdentifier];
    
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
}



- (void)restoreTransaction:(SKPaymentTransaction *)transaction {
    NSLog(@"restoreTransaction...");
   
   // [self recordTransaction: transaction];
   // [self provideContentForProductIdentifier:transaction.originalTransaction.payment.productIdentifier];
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
}

//- (void)failedTransaction:(SKPaymentTransaction *)transaction {
//    
//    NSLog(@"failedTransaction...");
//    if (transaction.error.code != SKErrorPaymentCancelled)
//    {
//        NSLog(@"Transaction error: %@", transaction.error.localizedDescription);
//    }
//    
//    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
//}

    
- (void)failedTransaction:(SKPaymentTransaction *)transaction {
    
    NSLog(@"The error description is:%@",[transaction.error description]);
    if (transaction.error.code == SKErrorPaymentCancelled)
    {
                if(transaction.error.code == SKErrorUnknown) {
            NSLog(@"Unknown Error (%d), product: %@", (int)transaction.error.code, transaction.payment.productIdentifier);
            UIAlertView *failureAlert = [[UIAlertView alloc] initWithTitle :@"In-App-Purchase Error:"
                                                                    message: @"There was an error purchasing this item please try again."
                                                                  delegate : self cancelButtonTitle:@"OK"otherButtonTitles:nil];
            
            [failureAlert show];
        }
        
        if(transaction.error.code == SKErrorClientInvalid) {
            NSLog(@"Client invalid (%d), product: %@", (int)transaction.error.code, transaction.payment.productIdentifier);
            UIAlertView *failureAlert = [[UIAlertView alloc] initWithTitle :@"In-App-Purchase Error:"
                                                                    message: @"There was an error purchasing this item please try again."
                                                                  delegate : self cancelButtonTitle:@"OK"otherButtonTitles:nil];
            [failureAlert show];
        }
        
        if(transaction.error.code == SKErrorPaymentInvalid) {
            NSLog(@"Payment invalid (%d), product: %@", (int)transaction.error.code, transaction.payment.productIdentifier);
            UIAlertView *failureAlert = [[UIAlertView alloc] initWithTitle :@"In-App-Purchase Error:"
                                                                    message: @"There was an error purchasing this item please try again."
                                                                  delegate : self cancelButtonTitle:@"OK"otherButtonTitles:nil];
            [failureAlert show];
        }
        
        if(transaction.error.code == SKErrorPaymentNotAllowed) {
            NSLog(@"Payment not allowed (%d), product: %@", (int)transaction.error.code, transaction.payment.productIdentifier);
            UIAlertView *failureAlert = [[UIAlertView alloc] initWithTitle :@"In-App-Purchase Error:"
                                                                    message: @"There was an error purchasing this item please try again."
                                                                  delegate : self cancelButtonTitle:@"OK"otherButtonTitles:nil];
            [failureAlert show];
        }
    }
    [[SKPaymentQueue defaultQueue] finishTransaction: transaction];
    [[NSNotificationCenter defaultCenter] postNotificationName:IAPHelperProductCancelledNotification  object:nil];

}


- (void)provideContentForProductIdentifier:(NSString *)productIdentifier {
    
    [_purchasedProductIdentifiers addObject:productIdentifier];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:productIdentifier];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:IAPHelperProductPurchasedNotification object:productIdentifier userInfo:nil];
   }

- (void)restoreCompletedTransactions {
    [[SKPaymentQueue defaultQueue] restoreCompletedTransactions];
}

@end