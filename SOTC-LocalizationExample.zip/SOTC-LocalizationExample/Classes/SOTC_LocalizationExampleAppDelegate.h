//
//  SOTC_LocalizationExampleAppDelegate.h
//  SOTC-LocalizationExample


#import <UIKit/UIKit.h>

@class SOTC_LocalizationExampleViewController;

@interface SOTC_LocalizationExampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SOTC_LocalizationExampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SOTC_LocalizationExampleViewController *viewController;

@end

