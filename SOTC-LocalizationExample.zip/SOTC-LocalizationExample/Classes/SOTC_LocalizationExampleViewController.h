//
//  SOTC_LocalizationExampleViewController.h
//  SOTC-LocalizationExample


#import <UIKit/UIKit.h>

@interface SOTC_LocalizationExampleViewController : UIViewController {
	IBOutlet UILabel *localeNameLabel;
	IBOutlet UILabel *labelToSetInCode;
}

@end

