//
//  SOTC_LocalizationExampleViewController.m
//  SOTC-LocalizationExample

#import "SOTC_LocalizationExampleViewController.h"

@implementation SOTC_LocalizationExampleViewController

- (void)viewDidLoad {
	NSLocale* curentLocale = [NSLocale currentLocale];
	localeNameLabel.text = [NSString stringWithFormat:
							NSLocalizedString(@"The current locale is: %@",
											  @"String used to display the current locale."),
	  [curentLocale displayNameForKey:NSLocaleIdentifier 
	                            value:[curentLocale localeIdentifier]]];
	
	labelToSetInCode.text = NSLocalizedString(@"This is my default value.", 
											  @"This is a comment about my default value string.");

    [super viewDidLoad];
}

@end
