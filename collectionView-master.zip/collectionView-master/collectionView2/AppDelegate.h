//
//  AppDelegate.h
//  collectionView2
//
//  Created by Корзун Владислав on 30.11.12.
//  Copyright (c) 2012 Корзун Владислав. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
