#import "MyCollectionViewController.h"
#import "MyCell.h"
#define animationDuration 0.3

@interface MyCollectionViewController ()
@property (nonatomic,strong) UISwipeGestureRecognizer * downRecognizer;
@property (nonatomic,strong) UISwipeGestureRecognizer * upRecognizer;
@end

@implementation MyCollectionViewController



- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    [self.collectionView registerClass:[MyCell class] forCellWithReuseIdentifier:@"cell"];
    self.collectionView.scrollEnabled = NO;
    [self setupLayout];
    [self setUpGesture];
}

-(void)setupLayout
{
    UICollectionViewFlowLayout * layout = (UICollectionViewFlowLayout *)self.collectionView.collectionViewLayout;
    layout.minimumLineSpacing = 3;
    layout.minimumInteritemSpacing = 3;
    layout.itemSize = CGSizeMake(self.view.bounds.size.height/2 - layout.minimumInteritemSpacing/2 ,self.view.bounds.size.width/2 - layout.minimumLineSpacing);
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;

}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 6;
}

-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MyCell * cell = (MyCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor whiteColor];
    [cell.button setTitle:[NSString stringWithFormat:@"%d",indexPath.row] forState:UIControlStateNormal];
    [cell.button setBackgroundImage:[UIImage imageNamed:@"InfoBox"] forState:UIControlStateNormal];

    return cell;
}

- (void)setUpGesture
{
    self.downRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(moveUp)];
    self.downRecognizer.direction = UISwipeGestureRecognizerDirectionDown;
    self.downRecognizer.cancelsTouchesInView = NO;
    [self.collectionView addGestureRecognizer:self.downRecognizer];
    self.upRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(moveDown)];
    self.upRecognizer.direction = UISwipeGestureRecognizerDirectionUp;
    self.upRecognizer.cancelsTouchesInView = NO;
    [self.collectionView addGestureRecognizer:self.upRecognizer];

}

- (void)moveDown
{
    [self turnGestureOff];
    if(self.collectionView.contentOffset.y < self.collectionView.contentSize.height - self.collectionView.bounds.size.height)
    
        [self.collectionView setContentOffset: CGPointMake(0,self.collectionView.contentOffset.y + self.collectionView.bounds.size.height) animated:YES];
    [self performSelector:@selector(turnGestureOn) withObject:nil afterDelay:animationDuration];
}

- (void)moveUp
{
    [self turnGestureOff];
    if(self.collectionView.contentOffset.y > 0)
        [self.collectionView setContentOffset:CGPointMake(0,self.collectionView.contentOffset.y - self.collectionView.bounds.size.height) animated:YES];
    [self performSelector:@selector(turnGestureOn) withObject:nil afterDelay:animationDuration];

}

- (void)turnGestureOff
{
    [self.collectionView removeGestureRecognizer:self.upRecognizer];
    [self.collectionView removeGestureRecognizer:self.downRecognizer];
}

- (void)turnGestureOn
{
    [self.collectionView addGestureRecognizer:self.upRecognizer];
    [self.collectionView addGestureRecognizer:self.downRecognizer];
}


@end
