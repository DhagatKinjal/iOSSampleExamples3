//
//  MyCell.m
//  collectionView2
//
//  Created by Корзун Владислав on 30.11.12.
//  Copyright (c) 2012 Корзун Владислав. All rights reserved.
//

#import "MyCell.h"

@implementation MyCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.button = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{ 
    
    self.button.frame = CGRectMake(0,0,self.frame.size.width,self.frame.size.height);
    self.button.backgroundColor = [UIColor redColor];
    [self.button addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [self.contentView addSubview:self.button];
}

- (void)buttonPressed:(id)sender
{
    NSLog(@"Button Pressed");
}


@end
