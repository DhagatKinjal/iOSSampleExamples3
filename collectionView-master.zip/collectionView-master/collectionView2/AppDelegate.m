//
//  AppDelegate.m
//  collectionView2
//
//  Created by Корзун Владислав on 30.11.12.
//  Copyright (c) 2012 Корзун Владислав. All rights reserved.
//

#import "AppDelegate.h"
#import "MyCollectionViewController.h"
@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
   [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];

    CGRect frame = [[UIScreen mainScreen] bounds];
    self.window = [[UIWindow alloc] initWithFrame:frame];
    
    UICollectionViewFlowLayout *aFlowLayout = [[UICollectionViewFlowLayout alloc] init];
  MyCollectionViewController *  collectionView = [[MyCollectionViewController alloc] initWithCollectionViewLayout:aFlowLayout];
        
    self.window.rootViewController = collectionView;
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}



@end
