This sample should automatically build and copy over the GTL.framework as part of the build-and-run process.
