//
//  main.m
//  PKRevealController
//
//  Created by Philip Kluz on 12/24/12.
//  Copyright (c) 2012 zuui.org. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PKAppDelegate class]));
    }
}
