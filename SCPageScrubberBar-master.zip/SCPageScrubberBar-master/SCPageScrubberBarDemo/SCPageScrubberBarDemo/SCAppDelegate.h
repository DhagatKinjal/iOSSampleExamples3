//
//  SCAppDelegate.h
//  SCPageScrubberBarDemo
//
//  Created by ohsc on 13-1-5.
//  Copyright (c) 2013年 Chao Shen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SCViewController;

@interface SCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SCViewController *viewController;

@end
