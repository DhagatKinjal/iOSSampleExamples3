//
//  main.m
//  SCPageScrubberBarDemo
//
//  Created by ohsc on 13-1-5.
//  Copyright (c) 2013年 Chao Shen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SCAppDelegate class]));
    }
}
