//
//  SCViewController.h
//  SCPageScrubberBarDemo
//
//  Created by ohsc on 13-1-5.
//  Copyright (c) 2013年 Chao Shen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SCViewController : UIViewController

@end
