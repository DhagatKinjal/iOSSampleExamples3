//
//  DBHandler1.h
//  SqliteOperationUsingTableView
//
//  Created by Mac_Admin on 23/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "sqlite3.h"
@interface DBHandler1 : UIView
{
    AppDelegate *appdel;
    sqlite3 *db;
    NSString *dataPath;
    
}

-(BOOL)insert:(NSArray *)arr;
-(BOOL)deletedata:(NSArray *)arr;
-(NSMutableArray *)selectinfo;

@end