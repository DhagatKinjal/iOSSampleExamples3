//
//  NextPage.m
//  SqliteOperationUsingTableView
//
//  Created by Mac_Admin on 23/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//


#import "NextPage.h"

@interface NextPage ()

@end

@implementation NextPage
@synthesize dbh,arrdata;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithTitle:@"Edit" style:UIBarButtonItemStyleBordered target:self action:@selector(EditTable:)];// add button bar to the view...
	[self.navigationItem setLeftBarButtonItem:addButton];//button at left side of the navi controller
    
    [self.navigationController.navigationBar setHidden:NO];//navigation not hidden
    //dbh=[[DBHandler alloc]init];
    arrdata=[dbh selectinfo];//database handdler
    [_tbl1 reloadData];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (IBAction) EditTable:(id)sender
{
	if(self.editing)//edit table data
	{
		[super setEditing:NO animated:NO];
		[_tbl1 setEditing:NO animated:NO];
		[_tbl1 reloadData];
		[self.navigationItem.leftBarButtonItem setTitle:@"Edit"];
		[self.navigationItem.leftBarButtonItem setStyle:UIBarButtonItemStylePlain];
	}
	else
	{
		[super setEditing:YES animated:YES];
		[_tbl1 setEditing:YES animated:YES];
		[_tbl1 reloadData];
		[self.navigationItem.leftBarButtonItem setTitle:@"Done"];
		[self.navigationItem.leftBarButtonItem setStyle:UIBarButtonItemStyleDone];
	}
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //remove the deleted object from your data source.
        //If you're data source is an NSMutableArray, do this
        [arrdata removeObjectAtIndex:indexPath.row];// for removing the table data in edit mode.
        [_tbl1 reloadData];
    }
}
-(void)viewWillAppear:(BOOL)animated
{
    arrdata=[dbh selectinfo];//table data reload with the db data....
    [_tbl1 reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_t1 release];
    [_t2 release];
    [_t3 release];
    [_tbl1 release];
    [_insertdata release];
    [super dealloc];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];//text field is return...
    return  YES;
}

- (IBAction)insertdata:(id)sender {
    @try {
        dbh=[[DBHandler1 alloc]init];//init db haddler..
        NSArray *arr=[NSArray arrayWithObjects:_t1.text,_t2.text,_t3.text, nil];// assign dynamic arr value
        if([dbh insert:arr])
        {
            self.arrdata=[dbh selectinfo];
            [_tbl1 reloadData];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"error: %@",exception);
    }
    @finally {
        
    }
    //
    //NSArray *a=[[NSArray alloc]init];
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.arrdata.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;//declare table view cell
    cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];//init cell
    if(cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];// init cell
        
    }
    
    
    NSArray *arr=[arrdata objectAtIndex:indexPath.section];//assign array to array
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];// assign arr to cell of tableview
    //cell.imageView.image=[[UIImageView alloc]initWithImage:img];
    return cell;
}


- (UITableViewCellAccessoryType)tableView:(UITableView *)tableView accessoryTypeForRowWithIndexPath:(NSIndexPath *)indexPath NS_DEPRECATED_IOS(2_0, 3_0)
{
    return UITableViewCellAccessoryCheckmark;//for check mark 
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"Student List";
}
//- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
//{
//
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];
    NSString *str=cell.textLabel.text;// cell of table is assign to string
    UIAlertView *alt1=[[UIAlertView alloc]initWithTitle:@"Status" message:str delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];//alert view de3claration and init...
    [alt1 show];
    [alt1 release];
}





@end
