//
//  ViewController.h
//  SqliteOperationUsingTableView
//
//  Created by Mac_Admin on 23/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler1.h"
@interface ViewController : UIViewController<UIAlertViewDelegate,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>
{
    NSArray *arr;
    NSMutableArray *marr;
    DBHandler1 *d;
}
@property (retain, nonatomic) IBOutlet UILabel *lbl2;
@property (retain, nonatomic)NSMutableArray *marr;
@property (retain, nonatomic)NSArray *arr;
@property (retain, nonatomic) IBOutlet UILabel *lbl1;
- (IBAction)displayAlert:(id)sender;
- (IBAction)nextview:(id)sender;

@property (retain, nonatomic) IBOutlet UITextField *t1;
@property (retain, nonatomic) IBOutlet UITextField *t2;
@property (retain, nonatomic) IBOutlet UITextField *t3;

@property (retain, nonatomic) IBOutlet UITableView *tbl1;

@end
