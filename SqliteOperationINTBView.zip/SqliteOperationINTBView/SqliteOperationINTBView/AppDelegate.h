//
//  AppDelegate.h
//  SqliteOperationUsingTableView
//
//  Created by Mac_Admin on 23/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//



#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate,UINavigationControllerDelegate>
{
    UINavigationController *nav;
    NSString *dbPath;
}
-(void)checkDB;

@property (strong, nonatomic)UINavigationController *nav;//navigation controller

@property (strong, nonatomic)NSString *dbpath;//database path variable

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@end
