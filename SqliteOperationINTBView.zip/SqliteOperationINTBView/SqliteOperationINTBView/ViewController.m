//
//  ViewController.m
//  SqliteOperationUsingTableView
//
//  Created by Mac_Admin on 23/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import "ViewController.h"
#import "NextPage.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize marr,arr;
- (void)viewDidLoad
{
    
    [self.navigationController.navigationBar setHidden:YES];//for hiding navigation
    self.title=@"MainView";//title
    marr=[[NSMutableArray alloc]init];//array initialization
    //[_tbl1 reloadData];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.navigationController.navigationBar setHidden:YES];//for hiding navigation
    //[_tbl1 reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [_lbl1 release];
    [_lbl2 release];
    [_t1 release];
    [_t2 release];
    [_tbl1 release];
    [_t3 release];
    [_tbl1 release];
    [super dealloc];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1)
    {
        UITextField *t=(UITextField*)[alertView textFieldAtIndex:0];//alert view with text
        _lbl2.text=t.text;//txtfield txt assign to lable text
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return marr.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];//init table view
    if(cell==nil)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];//init cell
        
    }
    
    UIImage *img=[UIImage imageNamed:@"Pumpkin"];//for image
    UIImageView *iv=[[UIImageView alloc]initWithImage:img];
    [iv setFrame:CGRectMake(50, 20, 30, 30)];//x,y and width and height
    [cell addSubview:iv];
    
    arr=[marr objectAtIndex:indexPath.section];//asssign array
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];//assign array to cell of the table
    //cell.imageView.image=[[UIImageView alloc]initWithImage:img];
    return cell;
}


- (UITableViewCellAccessoryType)tableView:(UITableView *)tableView accessoryTypeForRowWithIndexPath:(NSIndexPath *)indexPath NS_DEPRECATED_IOS(2_0, 3_0)
{
    return UITableViewCellAccessoryCheckmark;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return @"Student List";
}
//- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
//{
//
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView cellForRowAtIndexPath:indexPath];//init cell
    
    cell.accessoryType=UITableViewCellAccessoryCheckmark;//checkmark at tableview cell
    
    NSString *str=cell.textLabel.text;//cell text alert
    UIAlertView *alt1=[[UIAlertView alloc]initWithTitle:@"Status" message:str delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];//alert view
    [alt1 show];
    [alt1 release];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return  YES;
}
- (IBAction)displayAlert:(id)sender {
    
    UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Hi Uday..!" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];///alert view
    alt.alertViewStyle=UIAlertViewStylePlainTextInput;//textfield in alertview
    alt.tag=1;
    [alt show];
    [alt release];
    
    _lbl1.text=@"WelCome";//lable assign text
    
    
    arr=[[NSMutableArray alloc]initWithObjects:_t1.text,_t2.text, nil];//for object initialization
    [marr addObject:arr];//assign array to another dynamic array
    [_tbl1 reloadData];
    _t1.text=@"";
    _t2.text=@"";
}
- (IBAction)nextview:(id)sender {
    
    NextPage *n=[[NextPage alloc]initWithNibName:@"NextPage" bundle:nil];// init nextpage object
    [self.navigationController pushViewController:n animated:YES];// jump to next page.
    
}
@end
