//
//  NextPage.h
//  SqliteOperationINTBView
//
//  Created by Mac_Admin on 26/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DBHandler1.h"
@interface NextPage : UIViewController<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>
{
    DBHandler1 *dbh;
    NSMutableArray *arrdata;
}
@property (retain, nonatomic) IBOutlet UITableView *tbl1;
@property (retain, nonatomic) NSMutableArray *arrdata;
@property (retain, nonatomic) IBOutlet UITextField *t1;
@property (retain, nonatomic) IBOutlet UITextField *t2;
@property (retain, nonatomic) IBOutlet UITextField *t3;
@property (retain, nonatomic)DBHandler1 *dbh;
- (IBAction)insertdata:(id)sender;

@property (retain, nonatomic) IBOutlet UIView *insertdata;

@end
