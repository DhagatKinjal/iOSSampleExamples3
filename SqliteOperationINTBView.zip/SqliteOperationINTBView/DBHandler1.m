//
//  DBHandler1.m
//  SqliteOperationUsingTableView
//
//  Created by Mac_Admin on 23/04/13.
//  Copyright (c) 2013 Mac_Admin. All rights reserved.
//
#import "DBHandler1.h"

@implementation DBHandler1

//- (id)initWithFrame:(CGRect)frame
//{
//    self = [super initWithFrame:frame];
//    if (self) {
//
//        appdel=(AppDelegate*)[[UIApplication sharedApplication]delegate];
//
//        dataPath=[[NSString alloc]initWithString:appdel.dbpath];
//        // Initialization code
//    }
//    return self;
//}

-(id)init{
    if(self==[super init])
    {
        appdel=(AppDelegate*)[[UIApplication sharedApplication]delegate];// init delegate to the application eith data base
        
        dataPath=[[NSString alloc]initWithString:appdel.dbpath];//init database path with string
        
    }
    return  self;
}


-(BOOL)insert:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[[NSString alloc]initWithFormat:@"insert into student values(%d,'%@','%@')",[[arr objectAtIndex:0]intValue],[arr objectAtIndex:1],[arr objectAtIndex:2]];/// assign the arr value of textfield to the database table
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Record inserted" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];// alert for save the value to the db
            
            [alt show];
            [alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}

-(BOOL)deletedata:(NSArray *)arr
{
    BOOL isok=NO;
    NSString *query=[[NSString alloc]initWithFormat:@"delete from student where roll_no=%d ",[[arr objectAtIndex:0]intValue]];// delete query for db...
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            UIAlertView *alt=[[UIAlertView alloc]initWithTitle:@"Status" message:@"Record deleted" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            
            [alt show];
            [alt release];
            
        }
        sqlite3_finalize(stm);
    }
    
    sqlite3_close(db);
    return isok;
}


-(NSMutableArray*)selectinfo
{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSString *query=@"select * from student";//select the information in db table...
    
    if(sqlite3_open([dataPath UTF8String], &db)==SQLITE_OK)
        
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                NSMutableArray *Row=[[NSMutableArray alloc]init];
                
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 0)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 1)]];
                [Row addObject:[NSString stringWithUTF8String:(char *) sqlite3_column_text(stm, 2)]];
                
                [data addObject:Row];
                [Row release];
            }
            sqlite3_finalize(stm);
        }
        sqlite3_close(db);
    }
    return data;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
