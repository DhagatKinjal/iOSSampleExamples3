//
//  AppDelegate.m
//  FileSuffixesTest
//
//  Created by Nick Lockwood on 08/06/2012.
//
//

#import "AppDelegate.h"

@implementation AppDelegate

@synthesize window;

@end
