//
//  AppDelegate.h
//  FileSuffixesTest
//
//  Created by Nick Lockwood on 08/06/2012.
//
//

#import <Foundation/Foundation.h>

@interface AppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, strong) IBOutlet UIWindow *window;

@end
