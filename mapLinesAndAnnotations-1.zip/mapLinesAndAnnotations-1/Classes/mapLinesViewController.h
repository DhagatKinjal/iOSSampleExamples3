//
//  mapLinesViewController.h
//  mapLines
//
//  Created by Craig on 4/12/09.
//  Copyright Craig Spitzkoff 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@class CSWebDetailsViewController;

@interface mapLinesViewController : UIViewController <MKMapViewDelegate> {
	
	// the map view. 
	MKMapView* _mapView;
	
	// details view controller
	CSWebDetailsViewController* _detailsVC; 
	
	// dictionary of route views indexed by annotation
	NSMutableDictionary* _routeViews;
}

-(void) showWebViewForURL:(NSURL*) url;

@property (nonatomic, retain) MKMapView* mapView;

@end

