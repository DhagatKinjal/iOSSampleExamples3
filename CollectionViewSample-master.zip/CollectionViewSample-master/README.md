CollectionViewSample

CollectionViewを使った簡単なサンプルコード。
縦スクロール、レイアウトのカスタマイズなし

サンプル中の画像は以下のものを使用

<http://www.futta.net>
