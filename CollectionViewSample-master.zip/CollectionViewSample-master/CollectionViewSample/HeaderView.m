//
//  HeaderView.m
//  CollectionViewSample
//
//  Created by Natsuko Nishikata on 2012/09/17.
//  Copyright (c) 2012年 Natsuko Nishikata. All rights reserved.
//

#import "HeaderView.h"

@implementation HeaderView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
}
 */

@end
