//
//  ViewController.h
//  CollectionViewSample
//
//  Created by Natsuko Nishikata on 2012/09/17.
//  Copyright (c) 2012年 Natsuko Nishikata. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UICollectionViewController

@end
