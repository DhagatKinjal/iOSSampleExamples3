//
//  main.m
//  CollectionViewSample
//
//  Created by Natsuko Nishikata on 2012/09/20.
//  Copyright (c) 2012年 Natsuko Nishikata. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
