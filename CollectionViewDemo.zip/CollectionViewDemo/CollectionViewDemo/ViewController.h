//
//  ViewController.h
//  CollectionViewDemo
//
//  Created by RDC on 3/6/13.
//  Copyright (c) 2013 RDCWorld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UICollectionViewDataSource, UICollectionViewDelegate>

@property (weak, nonatomic) IBOutlet UICollectionView *myCollectionView;

@property (nonatomic, retain) NSMutableArray *contentArray;

@end
