//
//  ViewController.m
//  CollectionViewDemo
//
//  Created by RDC on 3/6/13.
//  Copyright (c) 2013 RDCWorld. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@end

@implementation ViewController

@synthesize myCollectionView;
@synthesize contentArray;

#pragma mark - ViewController's Life Cycle methods

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //initialize array and put data on it
    contentArray = [[NSMutableArray alloc] init];
	
    for (int i=0; i<100; i++) {
        [contentArray addObject:[NSString stringWithFormat:@"Cell %d",i]];
    }
    
    //get the cell nib we have created
    UINib *cellNib = [UINib nibWithNibName:@"MyCell" bundle:nil];
    [myCollectionView registerNib:cellNib forCellWithReuseIdentifier:@"cvCell"];
    
    //create flow layout
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout setItemSize:CGSizeMake(100, 100)];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    
    //add flow layout to our collection view
    [myCollectionView setCollectionViewLayout:flowLayout];
    
    //optional : if you didn't hook up Datasource and delegate with File owner, you can use this
    //myCollectionView.dataSource = self;
    //myCollectionView.delegate=self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

#pragma mark - UICollectionView DataSource methods


// DataSource - optional method
- (NSInteger)numberOfSectionsInCollectionView: (UICollectionView *)collectionView {
    return 1;
}

// DataSource - mandatory methods
-(NSInteger) collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [contentArray count];
}


-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *cellData = [contentArray objectAtIndex:indexPath.row];
    static NSString *cellIdentifier = @"cvCell";    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellIdentifier forIndexPath:indexPath];    
    UILabel *titleLabel = (UILabel *)[cell viewWithTag:100];    
    [titleLabel setText:cellData];    
    return cell;    
}

#pragma mark - UICollectionView Delegate method

// Delegate - optional method
-(void) collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *cellData = [contentArray objectAtIndex:indexPath.row];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:[NSString stringWithFormat:@"You have selected %@ item",cellData] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
    [alert show];
    
}

@end
