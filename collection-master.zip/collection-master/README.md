Collection example from http://skeuo.com/uicollectionview-custom-layout-tutorial
