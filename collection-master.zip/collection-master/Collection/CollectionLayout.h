//
//  CollectionLayout.h
//  Collection
//
//  Created by j on 7/9/13.
//  Copyright (c) 2013 j. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionLayout : UICollectionViewLayout

@property (nonatomic) UIEdgeInsets itemInsets;
@property (nonatomic) CGSize itemSize;
@property (nonatomic) CGFloat interItemSpacingY;
@property (nonatomic) NSInteger numberOfColumns;

@end
