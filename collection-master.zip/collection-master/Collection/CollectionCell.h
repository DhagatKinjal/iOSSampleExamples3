//
//  CollectionCell.h
//  Collection
//
//  Created by j on 7/9/13.
//  Copyright (c) 2013 j. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionCell : UICollectionViewCell

@property (nonatomic, strong, readonly) UIImageView *imageView;

@end
