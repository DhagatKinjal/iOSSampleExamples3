//
//  ViewController.h
//  Collection
//
//  Created by j on 7/9/13.
//  Copyright (c) 2013 j. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CollectionLayout.h"

@interface ViewController : UICollectionViewController <UICollectionViewDataSource, UICollectionViewDelegate>

@property (nonatomic, weak) IBOutlet CollectionLayout *collectionLayout;

@end
