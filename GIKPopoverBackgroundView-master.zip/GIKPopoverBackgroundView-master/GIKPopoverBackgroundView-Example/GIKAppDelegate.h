//
//  GIKAppDelegate.h
//  GIKPopoverBackgroundView
//
//  Created by Gordon Hughes on 1/7/13.
//  Copyright (c) 2013 Gordon Hughes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GIKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
