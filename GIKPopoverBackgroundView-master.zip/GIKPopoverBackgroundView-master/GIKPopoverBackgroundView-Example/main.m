//
//  main.m
//  GIKPopoverBackgroundView
//
//  Created by Gordon Hughes on 1/7/13.
//  Copyright (c) 2013 Gordon Hughes. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GIKAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GIKAppDelegate class]));
    }
}
