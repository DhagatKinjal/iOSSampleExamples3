package com.example;

import android.app.*;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class Main extends Activity {
    private static final int NOTIF_ID = 1234;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        // TOAST
        Toast.makeText(this, "Your download has resumed.", Toast.LENGTH_LONG).show();

        // NOTIFICATIONS
        NotificationManager notifManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification note = new Notification(R.drawable.icon, "New E-mail", System.currentTimeMillis());

        PendingIntent intent = PendingIntent.getActivity(this, 0, new Intent(this, Main.class), 0);

        note.setLatestEventInfo(this, "New E-mail", "You have one unread message.", intent);
        
        notifManager.notify(NOTIF_ID, note);

        // notifManager.cancel(NOTIF_ID);

        // ALERT DIALOGS
        new AlertDialog.Builder(this).setTitle("Argh").setMessage("Watch out!").setNeutralButton("Close", null).show();
        //new AlertDialog.Builder(this).setTitle("Argh").setMessage("Watch out!").setNegativeButton("Cancel", null).setPositiveButton("OK", null).setNeutralButton("No", null).show();
        //new AlertDialog.Builder(this).setTitle("Argh").setMessage("Watch out!").setNeutralButton("Close", null).show();
        //new AlertDialog.Builder(this).setTitle("Argh").setMessage("Watch out!").setIcon(R.drawable.icon).setNeutralButton("Close", null).show();
    }
}
