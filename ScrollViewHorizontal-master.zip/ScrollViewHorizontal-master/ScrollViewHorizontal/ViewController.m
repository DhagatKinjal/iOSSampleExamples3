//
//  ViewController.m
//  ScrollViewHorizontal
//
//  Created by Duong Nam Duong on 7/2/13.
//  Copyright (c) 2013 Duong Nam Duong. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
