//
//  AppDelegate.h
//  ScrollViewHorizontal
//
//  Created by Duong Nam Duong on 7/2/13.
//  Copyright (c) 2013 Duong Nam Duong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
