//
//  ScrollViewHorizontalTests.m
//  ScrollViewHorizontalTests
//
//  Created by Duong Nam Duong on 7/2/13.
//  Copyright (c) 2013 Duong Nam Duong. All rights reserved.
//

#import "ScrollViewHorizontalTests.h"

@implementation ScrollViewHorizontalTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in ScrollViewHorizontalTests");
}

@end
