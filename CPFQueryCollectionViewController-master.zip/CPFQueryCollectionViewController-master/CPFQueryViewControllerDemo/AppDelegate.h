//
//  AppDelegate.h
//  CPFQueryViewControllerDemo
//
//  Created by Hampus Nilsson on 10/8/12.
//  Copyright (c) 2012 FreedomCard. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
