//
//  ParseAppInfo.h
//  CPFQueryViewControllerDemo
//
//  Created by Hampus Nilsson on 10/8/12.
//  Copyright (c) 2012 FreedomCard. All rights reserved.
//

#ifndef CPFQueryViewControllerDemo_ParseAppInfo_h
#define CPFQueryViewControllerDemo_ParseAppInfo_h

// Enter your Parse.com application here to run the demo

const NSString *ParseApplicationID = @"";
const NSString *ParseClientKey = @"";

#endif
