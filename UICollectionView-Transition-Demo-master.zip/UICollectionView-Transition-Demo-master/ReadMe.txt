
Collection View Transition
==========================

This sample illustrates how to create a custom transition when navigating
between two collection views in a navigation hierarchy managed by a navigation
controller.

The application has two view collection view controllers that display cells.
You can transition from one to the other by tapping on an item. You can also
use a pinch gesture, in which case you can control the speed of, and even
reverse, the transition.

