//
//  Email.m
//  MailDemo
//
//  Created by Scott Stevenson on Wed Apr 21 2004.
//  Copyright (c) 2004 Tree House Ideas. All rights reserved.
//

#import "Email.h"


@implementation Email


- (id) init
{
    if (self = [super init])
    {
        NSArray * keys      = [NSArray arrayWithObjects: @"address", @"subject", @"date", @"body", nil];
        NSArray * values    = [NSArray arrayWithObjects: @"test@test.com", @"Subject", [NSDate date], [NSString string], nil];
        properties = [[NSMutableDictionary alloc] initWithObjects: values forKeys: keys];
    }
    return self;
}

- (void) dealloc
{
    [properties release];
    
    [super dealloc];
}



- (NSMutableDictionary *) properties
{
    return properties;
}

- (void) setProperties: (NSDictionary *)newProperties
{
    if (properties != newProperties)
    {
        [properties autorelease];
        properties = [[NSMutableDictionary alloc] initWithDictionary: newProperties];
    }
}




@end
