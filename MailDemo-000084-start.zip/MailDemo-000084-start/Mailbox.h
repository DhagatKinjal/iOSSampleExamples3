//
//  Mailbox.h
//  MailDemo
//
//  Created by Scott Stevenson on Wed Apr 21 2004.
//  Copyright (c) 2004 Tree House Ideas. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Mailbox : NSObject {

    NSMutableDictionary * properties;
    NSMutableArray      * emails;
}

- (NSMutableDictionary *) properties;
- (void) setProperties: (NSDictionary *)newProperties;

- (NSMutableArray *) emails;
- (void) setEmails: (NSArray *) newEmails;

@end
