#import "MyController.h"

@implementation MyController



#pragma mark -
#pragma mark Startup and Shutdown

- (id) init
{
    if (self = [super init])
    {
        _mailboxes = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void) dealloc
{
    [_mailboxes release];
    
    [super dealloc];
}



#pragma mark -
#pragma mark Simple Accessors

- (NSMutableArray *) mailboxes
{
    return _mailboxes;
}

- (void) setMailboxes: (NSArray *)newMailboxes
{
    if (_mailboxes != newMailboxes)
    {
        [_mailboxes autorelease];
        _mailboxes = [[NSMutableArray alloc] initWithArray: newMailboxes];
    }
}


@end
