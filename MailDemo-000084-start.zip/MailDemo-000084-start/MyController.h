/* MyController */

#import <Cocoa/Cocoa.h>

@interface MyController : NSObject
{
    NSMutableArray * _mailboxes;
}

// simple accessors

- (NSMutableArray *) mailboxes;
- (void) setMailboxes: (NSArray *)newMailboxes;

@end
