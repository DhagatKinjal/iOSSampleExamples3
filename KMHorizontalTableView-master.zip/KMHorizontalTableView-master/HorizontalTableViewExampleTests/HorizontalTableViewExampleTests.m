//
//  HorizontalTableViewExampleTests.m
//  HorizontalTableViewExampleTests
//
//  Created by Keith Moon on 24/11/2012.
//  Copyright (c) 2012 Keith. All rights reserved.
//

#import "HorizontalTableViewExampleTests.h"

@implementation HorizontalTableViewExampleTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HorizontalTableViewExampleTests");
}

@end
