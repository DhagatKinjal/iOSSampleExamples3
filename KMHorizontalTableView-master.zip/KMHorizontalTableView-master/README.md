KMHorizontalTableView
=====================

A horizontal implementation of a tableview-like scrollview. Using familiar structure, swapping references from rows to columns.