//
//  ScrollViewController.m
//  ImagesScrollView
//
//  Created by asif on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ScrollViewController.h"


@implementation ScrollViewController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
		imagesName = [[NSArray alloc]initWithObjects:@"on.png",@"one.png",@"two.png",@"three.png",
				  @"four.png",@"five.png",@"six.png",@"seven.png",nil];
		images = [[NSMutableArray alloc]init];
    }
    return self;
}



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	scrollView.delegate = self;
	scrollView.scrollEnabled = YES;
	int scrollWidth = 120;
	scrollView.contentSize = CGSizeMake(scrollWidth,80);	 

	
	int xOffset = 0;
	imageView.image = [UIImage imageNamed:[imagesName objectAtIndex:0]];
	
	for(int index=0; index < [imagesName count]; index++)
	{
		
		UIImageView *img = [[UIImageView alloc] init];
		img.bounds = CGRectMake(10, 10, 50, 50);
		img.frame = CGRectMake(5+xOffset, 0, 160, 110);
		NSLog(@"image: %@",[imagesName objectAtIndex:index]);
		img.image = [UIImage imageNamed:[imagesName objectAtIndex:index]];
		[images insertObject:img atIndex:index];		 
		scrollView.contentSize = CGSizeMake(scrollWidth+xOffset,110); 
		[scrollView addSubview:[images objectAtIndex:index]];
		
		xOffset += 170;
	}
	
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	
	UITouch * touch = [[event allTouches] anyObject];
	
	for(int index=0;index<[images count];index++)
	{
		UIImageView *imgView = [images objectAtIndex:index];
		NSLog(@"x=%f,y=%f,width =%f,height=%f",imgView.frame.origin.x,imgView.frame.origin.y,imgView.frame.size.width,imgView.frame.size.height);
		NSLog(@"x= %f,y=%f",[touch locationInView:self.view].x,[touch locationInView:self.view].y) ;
		
		if(CGRectContainsPoint([imgView frame], [touch locationInView:scrollView]))
		{
			[self ShowDetailView:imgView];
			break;
		}
	}
}

-(void)ShowDetailView:(UIImageView *)imgView
{
	imageView.image = imgView.image;		
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[images release];
	[imagesName release];
    [super dealloc];
}


@end
