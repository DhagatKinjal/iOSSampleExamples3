//
//  ScrollViewController.h
//  ImagesScrollView
//
//  Created by asif on 8/4/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ScrollView.h"

@interface ScrollViewController : UIViewController <UIScrollViewDelegate> {

	IBOutlet ScrollView *scrollView;
	IBOutlet UIImageView *imageView;
	NSMutableArray *images;
	NSArray *imagesName;
}
-(void)ShowDetailView:(UIImageView *)imgView;
@end
