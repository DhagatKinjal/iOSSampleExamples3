//
//  ScrollView.h
//  FighterPedia
//
//  Created by CS561 on 08/06/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ScrollView : UIScrollView {

}

@end
