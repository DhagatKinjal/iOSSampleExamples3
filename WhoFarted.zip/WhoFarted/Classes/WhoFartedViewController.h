//
//  WhoFartedViewController.h
//  WhoFarted
//
//  Created by Vivian Aranha on 12/8/10.
//  Copyright 2010 Self. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GameKit/GameKit.h>

@interface WhoFartedViewController : UIViewController {

	IBOutlet UILabel *lblScore;
	int *score;
}

-(IBAction)addScore;
-(IBAction)submitMyScore;
-(IBAction)showLeaderboard;
- (IBAction) showAchievements;

@end

