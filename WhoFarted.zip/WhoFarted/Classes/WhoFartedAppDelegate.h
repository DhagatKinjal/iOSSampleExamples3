//
//  WhoFartedAppDelegate.h
//  WhoFarted
//
//  Created by Vivian Aranha on 12/8/10.
//  Copyright 2010 Self. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WhoFartedViewController;

@interface WhoFartedAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    WhoFartedViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet WhoFartedViewController *viewController;

@end

