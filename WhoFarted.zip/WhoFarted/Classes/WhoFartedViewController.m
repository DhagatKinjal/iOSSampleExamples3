//
//  WhoFartedViewController.m
//  WhoFarted
//
//  Created by Vivian Aranha on 12/8/10.
//  Copyright 2010 Self. All rights reserved.
//

#import "WhoFartedViewController.h"

@implementation WhoFartedViewController



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[[GKLocalPlayer localPlayer] authenticateWithCompletionHandler:^(NSError *error){
		if (error ==nil) {
			NSLog(@"Success");
		} else {
			NSLog(@"Fail");
		}

	}];
}


-(IBAction)addScore{
	score += 10;
	NSString *scrVal = [NSString stringWithFormat:@"%d",score];
	lblScore.text = scrVal;
}

-(IBAction)submitMyScore{
	//This is the same category id you set in your itunes connect GameCenter LeaderBoard
	GKScore *myScoreValue = [[[GKScore alloc] initWithCategory:@"testleaderboard"] autorelease];
	myScoreValue.value = score;
	
	[myScoreValue reportScoreWithCompletionHandler:^(NSError *error){
		if(error != nil){
			NSLog(@"Score Submission Failed");
		} else {
			NSLog(@"Score Submitted");
		}

	}];
	[self checkAchievements];
}

- (void) checkAchievements
{
	if(score > 1000){
		GKAchievement *achievement= [[[GKAchievement alloc] initWithIdentifier:@"testachievement"] autorelease];
		achievement.percentComplete = 100.0;
		if(achievement!= NULL)
		{
			[achievement reportAchievementWithCompletionHandler: ^(NSError *error){
				if(error != nil){
					NSLog(@"Achievement failed");
				} else {
					NSLog(@"Achievement Success");
				}

			 }];
		}
	}
}



-(IBAction)showLeaderboard{
	GKLeaderboardViewController *lb = [[GKLeaderboardViewController alloc] init];
	if(lb != nil){
		lb.leaderboardDelegate = self;
		[self presentModalViewController:lb animated:YES];
	}
}

- (void)leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
	[self dismissModalViewControllerAnimated: YES];
	[viewController release];
}

- (IBAction) showAchievements
{
	GKAchievementViewController *achievements = [[GKAchievementViewController alloc] init];
	if (achievements != NULL)
	{
		achievements.achievementDelegate = self;
		[self presentModalViewController:achievements animated: YES];
	}
}

- (void)achievementViewControllerDidFinish:(GKAchievementViewController *)viewController;
{
	[self dismissModalViewControllerAnimated: YES];
	[viewController release];
}

@end
