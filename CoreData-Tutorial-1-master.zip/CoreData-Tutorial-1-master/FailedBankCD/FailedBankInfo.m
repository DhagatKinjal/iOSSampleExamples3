//
//  FailedBankInfo.m
//  FailedBankCD
//
//  Created by Adam Burkepile on 3/23/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "FailedBankInfo.h"


@implementation FailedBankInfo

@dynamic name;
@dynamic city;
@dynamic state;
@dynamic details;

@end
