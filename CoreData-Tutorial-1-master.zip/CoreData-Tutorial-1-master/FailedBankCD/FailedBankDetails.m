//
//  FailedBankDetails.m
//  FailedBankCD
//
//  Created by Adam Burkepile on 3/23/12.
//  Copyright (c) 2012 Adam Burkepile. All rights reserved.
//

#import "FailedBankDetails.h"
#import "FailedBankInfo.h"


@implementation FailedBankDetails

@dynamic zip;
@dynamic closeDate;
@dynamic updateDate;
@dynamic info;

@end
