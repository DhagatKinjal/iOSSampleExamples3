//
//  main.m
//  ToastTest
//
//  Copyright 2013 Charles Scalesse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ToastTestAppDelegate.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ToastTestAppDelegate class]));
    }
}