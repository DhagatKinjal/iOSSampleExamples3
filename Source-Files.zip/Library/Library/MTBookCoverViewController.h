//
//  MTBookCoverViewController.h
//  Library
//
//  Created by Bart Jacobs on 19/12/12.
//  Copyright (c) 2012 Mobile Tuts. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTBookCoverViewController : UIViewController

@property UIImage *bookCover;
@property IBOutlet UIImageView *bookCoverView;

@end
