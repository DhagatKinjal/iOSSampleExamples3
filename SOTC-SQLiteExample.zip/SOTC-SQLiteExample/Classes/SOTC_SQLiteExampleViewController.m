//
//  SOTC_SQLiteExampleViewController.m
//  SOTC-SQLiteExample

#import "SOTC_SQLiteExampleViewController.h"
#import "/usr/include/sqlite3.h"

@implementation SOTC_SQLiteExampleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	
	UIAlertView *view;
	
	sqlite3 *database;
	int result = sqlite3_open("/myExampleDatabase.db", &database);
	if(result != SQLITE_OK)
	{
		sqlite3_close(database);
		view = [[UIAlertView alloc]
		   initWithTitle: @"Database Error"
		   message: @"Failed to open database."
		   delegate: self
		   cancelButtonTitle: @"Hrm." otherButtonTitles: nil];
		[view show];
		[view autorelease];
		return;
	}
	
	sqlite3_exec(database,
				 "CREATE TABLE IF NOT EXISTS Messages (ID INTEGER PRIMARY KEY AUTOINCREMENT, Message TEXT)",
				 NULL, NULL, NULL);
	
	NSDate *today = [NSDate date];
	NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
	[dateFormat setDateFormat:@"EEEE MMMM d, YYYY h:mm a, zzz"];
	sqlite3_exec(database, [[NSString stringWithFormat:@"INSERT INTO Messages VALUES(NULL, 'You ran the app at %@')", 
							 [dateFormat stringFromDate:today]] UTF8String],
				 NULL, NULL, NULL);	
	[dateFormat release];
	
	sqlite3_stmt *statement;
	sqlite3_prepare_v2(database, "SELECT Message FROM Messages", -1, &statement, nil);
	
	while(sqlite3_step(statement) == SQLITE_ROW)
	{
		NSString *message = [[NSString alloc] initWithUTF8String:(char *)sqlite3_column_text(statement, 0)];
		view = [[UIAlertView alloc]
				initWithTitle: @"A Message"
				message: message
				delegate: self
				cancelButtonTitle: @"Woot!" otherButtonTitles: nil];
		[view show];
		[view autorelease];
		[message release];
	}
	
	sqlite3_finalize(statement);
	sqlite3_close(database);
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
