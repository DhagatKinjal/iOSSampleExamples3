//
//  SOTC_SQLiteExampleAppDelegate.h
//  SOTC-SQLiteExample

#import <UIKit/UIKit.h>

@class SOTC_SQLiteExampleViewController;

@interface SOTC_SQLiteExampleAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SOTC_SQLiteExampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SOTC_SQLiteExampleViewController *viewController;

@end

