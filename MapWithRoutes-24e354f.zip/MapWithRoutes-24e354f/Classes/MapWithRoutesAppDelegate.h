//
//  MapWithRoutesAppDelegate.h
//  MapWithRoutes
//
//  Created by Sugartin on 11/16/2012.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@class MapWithRoutesViewController;

@interface MapWithRoutesAppDelegate : NSObject <UIApplicationDelegate,CLLocationManagerDelegate> {
    UIWindow *window;
    MapWithRoutesViewController *viewController;
}
@property (nonatomic, strong) CLLocation *userlocation;
@property (nonatomic, retain)CLLocationManager *locationManager;
@property (nonatomic,strong) UIViewController *controllerID;


@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MapWithRoutesViewController *viewController;

@end

