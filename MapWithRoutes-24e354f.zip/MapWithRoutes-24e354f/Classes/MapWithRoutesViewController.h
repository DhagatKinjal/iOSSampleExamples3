//
//  MapWithRoutesViewController.h
//  MapWithRoutes
//
//  Created by Sugartin on 11/16/2012.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MapView.h"
#import "Place.h"

@interface MapWithRoutesViewController : UIViewController<CLLocationManagerDelegate> {
    CLLocationManager *locationManager;
    IBOutlet UILabel *latLabel;
    IBOutlet UILabel *longLabel;
    MapView* mapView;
}

@end

