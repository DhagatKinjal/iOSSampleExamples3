//
//  MapWithRoutesViewController.m
//  MapWithRoutes
//
//  Created by Sugartin on 11/16/2012.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import "MapWithRoutesViewController.h"
#import "MapWithRoutesAppDelegate.h"
@implementation MapWithRoutesViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];

	mapView = [[[MapView alloc] initWithFrame:
						 CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)] autorelease];
	
	[self.view addSubview:mapView];
    [self performSelector:@selector(LoadMaps) withObject:self afterDelay:1.0];
}

-(void)LoadMaps{
    MapWithRoutesAppDelegate *app = (MapWithRoutesAppDelegate *)[[UIApplication sharedApplication]delegate];
    CLLocation *location = app.userlocation;
    // Configure the new event with information from the location
    CLLocationCoordinate2D coordinate = [location coordinate];
    
    NSString *latitude = [NSString stringWithFormat:@"%f", coordinate.latitude];
    NSString *longitude = [NSString stringWithFormat:@"%f", coordinate.longitude];
    
    NSLog(@"dLatitude : %@", latitude);
    NSLog(@"dLongitude : %@",longitude);
    
    
    Place* home = [[[Place alloc] init] autorelease];
	home.name = @"Home";
	home.description = @"Sweet home";
	home.latitude = coordinate.latitude;
	home.longitude = coordinate.longitude;
	
	Place* office = [[[Place alloc] init] autorelease];
	office.name = @"Office";
	office.description = @"Bad office";
	office.latitude = 23.329404;
	office.longitude = 72.0039299;
	
	[mapView showRouteFrom:home to:office];
    NSLog(@"latitide:%.7f, longitude: %.7f ", coordinate.latitude, coordinate.longitude);
}
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
