//
//  MapWithRoutesAppDelegate.m
//  MapWithRoutes
//
//  Created by Sugartin on 11/16/2012.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//

#import "MapWithRoutesAppDelegate.h"
#import "MapWithRoutesViewController.h"
#import "MapWithRoutesAppDelegate.h"

@implementation MapWithRoutesAppDelegate

@synthesize window;
@synthesize viewController;
@synthesize locationManager;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    [self.locationManager startUpdatingLocation];
    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}
#pragma mark- CLLocationManager delegate
- (void)locationManager:(CLLocationManager *)manager
    didUpdateToLocation:(CLLocation *)newLocation
           fromLocation:(CLLocation *)oldLocation{
    MapWithRoutesAppDelegate *app = (MapWithRoutesAppDelegate*)[[UIApplication sharedApplication] delegate];
    app.userlocation = newLocation;
    NSLog(@"latitide:%.7f, longitude: %.7f ", app.userlocation.coordinate.latitude, app.userlocation.coordinate.longitude);
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error{
    NSLog(@"locationManager %@",[error localizedDescription]);
}

- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
