MapWithRoutes
=============

This is a sample IPhone application demonstrates drawing routes on MKMapView using unofficial Google directions api reverse engineered by MapKi

This project is not maintained, please feel free to improve.

References:
-----------
 * http://mapki.com/wiki/Main_Page
 * http://spitzkoff.com/craig/?p=65
 * http://unitstep.net/blog/2008/08/02/decoding-google-maps-encoded-polylines-using-php


<img src="https://github.com/kadirpekel/MapWithRoutes/raw/master/screenshot.jpg" alt="screenshot" /> 