//
//  ViewController.m
//  TestTalkingTomiOS
//
//  Created by PC78 Elisoft on 12/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize imageView, animationData;
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
- (void) animationShowFrame: (NSInteger) frame {
	if ((frame >= animationNumFrames) || (frame < 0))
		return;
	
	NSData *data = [animationData objectAtIndex:frame];
	UIImage *img = [UIImage imageWithData:data];
	imageView.image = img;
}
-(void) testAnimation
{
    // create the view that will execute our animation
    UIImageView* campFireView = [[UIImageView alloc] initWithFrame:self.view.frame];
   
    NSMutableArray *arrayMutuable = [[NSMutableArray alloc] init] ;   
    for (int i = 1 ; i < 33; i++) {
        [arrayMutuable addObject:[UIImage imageNamed:[NSString stringWithFormat:@"fart_%04d.jpg",i]]];
    }   
    NSArray *imageArray = [[NSArray alloc] initWithArray:arrayMutuable];
    
    campFireView.animationImages = imageArray;
    [arrayMutuable release];
    [imageArray release];
    // all frames will execute in 1.75 seconds
    campFireView.animationDuration = 1.75;
    // repeat the annimation forever
    campFireView.animationRepeatCount = 3;

    // start animating
    [campFireView startAnimating];
    // add the animation view to the main window 
    [self.view addSubview:campFireView];
    [campFireView release]; 
}
-(void) testAnimation2
{
    // create the view that will execute our animation
    UIImageView* campFireView = [[UIImageView alloc] initWithFrame:self.view.frame];
    NSMutableArray *arrayMutuable = [[[NSMutableArray alloc] init] autorelease];   
    for (int i = 1 ; i < 54; i++) {
        [arrayMutuable addObject:[UIImage imageNamed:[NSString stringWithFormat:@"pet_%04d.jpg",i]]];
    }   
    NSArray *imageArray = [[NSArray alloc] initWithArray:arrayMutuable];
    campFireView.animationImages = imageArray;
    // load all the frames of our animation
    [imageArray release]; 
    // all frames will execute in 1.75 seconds
    campFireView.animationDuration = 1.75;
    // repeat the annimation forever
    campFireView.animationRepeatCount = 3;
    // start animating
    [campFireView startAnimating];
    // add the animation view to the main window 
    [self.view addSubview:campFireView];
    [campFireView release]; 
}
-(void) changeImageProgramtically:(id)sender
{
    NSLog(@"a ha");
    indexMainSprite ++;
    if (indexMainSprite < max_IndexMainSprite - 1) {
        
    }
    else
    {
        indexMainSprite = 0;
    }
    [campFireViewRotate setImage:[imageArrayRotate objectAtIndex:indexMainSprite]];
    [self performSelector:@selector(changeImageProgramtically:) withObject:nil afterDelay:0.05];
}
-(void) testAnimate3
{
    indexMainSprite = 0;
    max_IndexMainSprite = 54;
    // create the view that will execute our animation
    campFireViewRotate = [[[UIImageView alloc] initWithFrame:self.view.frame] retain];
    NSMutableArray *arrayMutuable = [[[NSMutableArray alloc] init] autorelease];   
    for (int i = 1 ; i < max_IndexMainSprite; i++) {
        [arrayMutuable addObject:[UIImage imageNamed:[NSString stringWithFormat:@"pet_%04d.jpg",i]]];
    }   
    imageArrayRotate = [[[NSArray alloc] initWithArray:arrayMutuable] retain];
    /*
    campFireView.animationImages = imageArrayRotate;
    // load all the frames of our animation

    // all frames will execute in 1.75 seconds
    campFireView.animationDuration = 1.75;
    // repeat the annimation forever
    campFireView.animationRepeatCount = 3;
    // start animating
    [campFireView startAnimating];
     */
    
    [campFireViewRotate setImage:[imageArrayRotate objectAtIndex:0]];
    [self performSelector:@selector(changeImageProgramtically:) withObject:nil afterDelay:0.05];
    [self.view addSubview:campFireViewRotate];

}
-(IBAction) testAnimation3:(id)sender
{
    [self testAnimate3];
}

- (void)viewDidLoad
{   
    [super viewDidLoad];
   
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}
#pragma mark IBAction implement
-(IBAction)TestAnimate:(id)sender
{
    [self testAnimation];
}
-(IBAction)testAnimate2:(id)sender
{
    [self testAnimation2];
}
#pragma mark Test Touch
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    NSLog(@"Test oki");
    [imageView stopAnimating];

}
@end
