//
//  ViewController.h
//  TestTalkingTomiOS
//
//  Created by PC78 Elisoft on 12/5/11.
//  Copyright (c) 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSArray *animationData;
    UIImageView *imageView;
    
    NSTimer *animationTimer;
	NSTimeInterval animationDuration;
    
    NSInteger animationNumFrames;
    
    //test for Humanmedical app
    NSArray *imageArrayRotate;
    UIImageView* campFireViewRotate; 
    int indexMainSprite;
    int max_IndexMainSprite;
}
-(IBAction)TestAnimate:(id)sender;
-(IBAction)testAnimate2:(id)sender;
-(IBAction) testAnimation3:(id)sender;
@property (nonatomic, retain) UIImageView *imageView;
@property (nonatomic, copy) NSArray *animationData;
@end
