//
//  ViewController.m
//  MapKit Animated Overlays
//
//  Created by Robert Ryan on 4/29/13.
//  Copyright (c) 2013 Robert Ryan. All rights reserved.
//

#import "ViewController.h"
#import <MapKit/MapKit.h>

@interface ViewController () <MKMapViewDelegate>

@property (nonatomic, strong) NSMutableArray *coordinates;
@property (nonatomic, weak) MKPolyline *polyLine;                  // used during the drawing of the polyline, but discarded once the MKPolygon is added
@property (nonatomic, weak) MKPointAnnotation *previousAnnotation; // if you're using other annotations, you might want to use a custom annotation type here
@property (nonatomic) BOOL isDrawingPolygon;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
  
    
    UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(foundTap:)];
    tapRecognizer.numberOfTapsRequired = 1;
    tapRecognizer.numberOfTouchesRequired = 1;
    [self.mapView addGestureRecognizer:tapRecognizer];
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
}

- (void)longpressToGetLocation:(UIGestureRecognizer *)gestureRecognizer
{
    if (gestureRecognizer.state != UIGestureRecognizerStateBegan)
        return;
    
    CGPoint touchPoint = [gestureRecognizer locationInView:self.mapView];
    CLLocationCoordinate2D location =
    [self.mapView convertPoint:touchPoint toCoordinateFromView:self.mapView];
    
    NSLog(@"Location found from Map: %f %f",location.latitude,location.longitude);
    
}

-(IBAction)foundTap:(UITapGestureRecognizer *)recognizer
{
    CGPoint point = [recognizer locationInView:self.mapView];
    
    CLLocationCoordinate2D tapPoint = [self.mapView convertPoint:point toCoordinateFromView:self.view];
    
    MKPointAnnotation *point1 = [[MKPointAnnotation alloc] init];
    
    point1.coordinate = tapPoint;
    
    float lat=point1.coordinate.latitude;
    float lon=point1.coordinate.longitude;
    NSLog(@"%f\n%f",lat,lon);
    
    
    [self.mapView addAnnotation:point1];
    
    /////
    CLLocationCoordinate2D center = {lat, lon};
    
    // Add an overlay
    MKCircle *circle = [MKCircle circleWithCenterCoordinate:center radius:500];
    [self.mapView addOverlay:circle];
    
    
    
//    CLLocationCoordinate2D  points[4];
//    
//    points[0] = CLLocationCoordinate2DMake(41.000512, -109.050116);
//    points[1] = CLLocationCoordinate2DMake(41.002371, -102.052066);
//    points[2] = CLLocationCoordinate2DMake(36.993076, -102.041981);
//    points[3] = CLLocationCoordinate2DMake(36.99892, -109.045267);
//    
//    MKPolygon* poly = [MKPolygon polygonWithCoordinates:points count:4];
//    poly.title = @"Colorado";
//    
//    [self.mapView addOverlay:poly];
//    
//    CGPoint point = [recognizer locationInView:self.mapView];
//   
//    
//    
//    CLLocationCoordinate2D tapPoint = [self.mapView convertPoint:point toCoordinateFromView:self.view];
}

//- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id<MKOverlay>)overlay
//{
//   
//}


//- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
//{
//    if ([overlay isKindOfClass:[MKPolygon class]])
//    {
//        MKPolygonView*    aView = [[MKPolygonView alloc] initWithPolygon:(MKPolygon*)overlay] ;
//        
//        aView.fillColor = [[UIColor cyanColor] colorWithAlphaComponent:0.2];
//        aView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
//        aView.lineWidth = 3;
//        
//        return aView;
//    }
//    
//    return nil;
//}
- (IBAction)didTouchUpInsideDrawButton:(id)sender
{
    if (!self.isDrawingPolygon)
    {
        // We're starting the drawing of our polyline/polygon, so
        // let's initialize everything
        
        self.isDrawingPolygon = YES;
        
        self.coordinates = [NSMutableArray array];
        
        // turn off map interaction so touches can fall through to
        // here
        
        self.mapView.userInteractionEnabled = NO;
        
        // change our "draw overlay" button to "done"
        
        [self.drawOverlayButton setTitle:@"Done"];
    }
    else
    {
        // We're finishing the drawing of our polyline, so let's
        // clean up, remove polyline, and add polygon
        
        self.isDrawingPolygon = NO;
        
        // let's restore map interaction
        
        self.mapView.userInteractionEnabled = YES;
        
        // and, if we drew more than two points, let's draw our polygon
        
        NSInteger numberOfPoints = [self.coordinates count];
        
        if (numberOfPoints > 2)
        {
            CLLocationCoordinate2D points[numberOfPoints];
            for (NSInteger i = 0; i < numberOfPoints; i++)
                points[i] = [self.coordinates[i] MKCoordinateValue];
            [self.mapView addOverlay:[MKPolygon polygonWithCoordinates:points count:numberOfPoints]];
        }
        
        // and if we had a polyline, let's remove it
        
        if (self.polyLine)
            [self.mapView removeOverlay:self.polyLine];
        
        // change our "draw overlay" button to "done"
        
        [self.drawOverlayButton setTitle:@"Draw overlay"];
        
        // remove our old point annotation
        
        if (self.previousAnnotation)
            [self.mapView removeAnnotation:self.previousAnnotation];
    }
}

- (void)addCoordinate:(CLLocationCoordinate2D)coordinate replaceLastObject:(BOOL)replaceLast
{
    if (replaceLast && [self.coordinates count] > 0)
        [self.coordinates removeLastObject];
    
    [self.coordinates addObject:[NSValue valueWithMKCoordinate:coordinate]];
    
    NSInteger numberOfPoints = [self.coordinates count];
    
    // if we have more than one point, then we're drawing a line segment
    
    if (numberOfPoints > 1)
    {
        MKPolyline *oldPolyLine = self.polyLine;
        CLLocationCoordinate2D points[numberOfPoints];
        for (NSInteger i = 0; i < numberOfPoints; i++)
            points[i] = [self.coordinates[i] MKCoordinateValue];
        MKPolyline *newPolyLine = [MKPolyline polylineWithCoordinates:points count:numberOfPoints];
        [self.mapView addOverlay:newPolyLine];
        
        self.polyLine = newPolyLine;
        
        // note, remove old polyline _after_ adding new one, to avoid flickering effect
        
        if (oldPolyLine)
            [self.mapView removeOverlay:oldPolyLine];
        
    }
    
    // let's draw an annotation where we tapped
    
    MKPointAnnotation *newAnnotation = [[MKPointAnnotation alloc] init];
    newAnnotation.coordinate = coordinate;
    [self.mapView addAnnotation:newAnnotation];
    
    // if we had an annotation for the previous location, remove it
    
    if (self.previousAnnotation)
        [self.mapView removeAnnotation:self.previousAnnotation];
    
    // and save this annotation for future reference
    
    self.previousAnnotation = newAnnotation;
}

- (BOOL)isClosingPolygonWithCoordinate:(CLLocationCoordinate2D)coordinate
{
    if ([self.coordinates count] > 2)
    {
        CLLocationCoordinate2D startCoordinate = [self.coordinates[0] MKCoordinateValue];
        CGPoint start = [self.mapView convertCoordinate:startCoordinate
                                          toPointToView:self.mapView];
        CGPoint end = [self.mapView convertCoordinate:coordinate
                                        toPointToView:self.mapView];
        CGFloat xDiff = end.x - start.x;
        CGFloat yDiff = end.y - start.y;
        CGFloat distance = sqrtf(xDiff * xDiff + yDiff * yDiff);
        if (distance < 30.0)
        {
            [self.coordinates removeLastObject];
            return YES;
        }
    }
    
    return NO;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (!self.isDrawingPolygon)
        return;
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.mapView];
    CLLocationCoordinate2D coordinate = [self.mapView convertPoint:location toCoordinateFromView:self.mapView];
    
    [self addCoordinate:coordinate replaceLastObject:NO];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (!self.isDrawingPolygon)
        return;
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.mapView];
    CLLocationCoordinate2D coordinate = [self.mapView convertPoint:location toCoordinateFromView:self.mapView];
    
    [self addCoordinate:coordinate replaceLastObject:YES];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (!self.isDrawingPolygon)
        return;
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.mapView];
    CLLocationCoordinate2D coordinate = [self.mapView convertPoint:location toCoordinateFromView:self.mapView];
    
    [self addCoordinate:coordinate replaceLastObject:YES];
    
    // detect if this coordinate is close enough to starting
    // coordinate to qualify as closing the polygon
    
    if ([self isClosingPolygonWithCoordinate:coordinate])
        [self didTouchUpInsideDrawButton:nil];
}

#pragma mark - MKMapViewDelegate

- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
    MKOverlayPathView *overlayPathView;
    
    if ([overlay isKindOfClass:[MKPolygon class]])
    {
        overlayPathView = [[MKPolygonView alloc] initWithPolygon:(MKPolygon*)overlay];
        
        overlayPathView.fillColor = [[UIColor cyanColor] colorWithAlphaComponent:0.2];
        overlayPathView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
        overlayPathView.lineWidth = 3;
        
        return overlayPathView;
    }
    
    else if ([overlay isKindOfClass:[MKPolyline class]])
    {
        overlayPathView = [[MKPolylineView alloc] initWithPolyline:(MKPolyline *)overlay];
        
        overlayPathView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
        overlayPathView.lineWidth = 3;
        
        return overlayPathView;
    }
    if ([overlay isKindOfClass:[MKPolygon class]])
    {
        MKPolygonView*    aView = [[MKPolygonView alloc] initWithPolygon:(MKPolygon*)overlay] ;
        
        aView.fillColor = [[UIColor cyanColor] colorWithAlphaComponent:0.2];
        aView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.7];
        aView.lineWidth = 3;
        
        return aView;
    }

    MKCircleView *circleView = [[MKCircleView alloc] initWithOverlay:overlay];
    [circleView setFillColor:[UIColor redColor]];
    [circleView setStrokeColor:[UIColor blackColor]];
    [circleView setAlpha:0.6f];
    return circleView;
    
    //return nil;
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    static NSString * const annotationIdentifier = @"CustomAnnotation";
    
    MKAnnotationView *annotationView = [mapView dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
    
    if (annotationView)
    {
        annotationView.annotation = annotation;
    }
    else
    {
        annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationIdentifier];
        annotationView.image = [UIImage imageNamed:@"annotation.png"];
        annotationView.alpha = 0.5;
    }
    
    annotationView.canShowCallout = NO;
    
    return annotationView;
}

@end
