// Compile with the following command:
//     g++ TestCPP.cpp -o TestCPP


#include <iostream>     // for cout
#include <stdlib.h>     // for rand()

using namespace std;    // so I can write "cout" instead of "std::cout"


int main(int argc, const char *argv[])
{
    int j;
    double k;

    cout << "Hello World!" << endl;

    cout << "There are " << argc << " parameters:\n";
    for(j=0; j<argc; j++)
        cout << argv[j] << endl;

    k = ((double)rand()/(double)RAND_MAX);
    cout << "Here is a random double: " << k << endl;
	
    return 0;
}

