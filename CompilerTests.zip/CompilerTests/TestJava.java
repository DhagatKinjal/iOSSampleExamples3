// Compile with the following command:
//     javac TestJava.java


import java.util.Random;


class TestJava
{
    public static void main(String[] args)
    {
        int argc, j;
        Random generator;
        double k;

        System.out.printf("Hello World!\n");

        argc = args.length;
        System.out.printf("There are %d parameters:\n", argc);
        for(j=0; j<argc; j++)
            System.out.printf("%s\n", args[j]);

        generator = new Random();
        k = generator.nextDouble();
        System.out.printf("Here is a random double: %f\n", k);
    }
	
}
