// Compile with the following command:
//     gcc TestObjC.m -o TestObjC


#import <stdio.h>       // for printf()
#import <stdlib.h>      // for rand()


int main(int argc, const char *argv[])
{
    int j;
    double k;

    printf("Hello World!\n");

    printf("There are %d parameters:\n", argc);
    for(j=0; j<argc; j++)
        printf("%s\n", argv[j]);

    k = ((double)rand()/(double)RAND_MAX);
    printf("Here is a random double: %f\n", k);
	
    return 0;
}

