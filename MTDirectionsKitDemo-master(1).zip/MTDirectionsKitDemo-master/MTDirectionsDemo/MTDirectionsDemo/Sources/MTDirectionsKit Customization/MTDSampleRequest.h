//
//  MTDSampleRequest.h
//  MTDirectionsKitDemo
//
//  Created by Matthias Tretter on 20.09.12.
//  Copyright (c) 2012 Matthias Tretter (@myell0w). All rights reserved.
//

#import <MTDirectionsKit/MTDirectionsKit.h>

@interface MTDSampleRequest : MTDDirectionsRequest

@end
