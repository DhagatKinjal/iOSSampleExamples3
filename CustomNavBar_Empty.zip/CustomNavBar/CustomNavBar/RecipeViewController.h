//
//  RecipeViewController.h
//  CustomNavBar
//
//  Created by Simon on 30/12/12.
//  Copyright (c) 2012 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecipeViewController : UITableViewController

@end
