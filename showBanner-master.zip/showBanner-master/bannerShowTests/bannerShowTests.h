//
//  bannerShowTests.h
//  bannerShowTests
//
//  Created by Alexey on 30.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface bannerShowTests : SenTestCase

@end
