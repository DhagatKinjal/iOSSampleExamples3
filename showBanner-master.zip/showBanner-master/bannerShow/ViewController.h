//
//  ViewController.h
//  bannerShow
//
//  Created by Alexey on 30.07.12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class BannerView;
@interface ViewController : UIViewController
@property BannerView *banner;
@end
