//
//  FrontViewControllerBlocksViewController.h
//  RevealControllerProject3
//
//  Created by Joan on 30/12/12.
//
//

#import <UIKit/UIKit.h>

@interface FrontViewControllerLabel : UIViewController

@property (nonatomic) IBOutlet UILabel *label;
@property (nonatomic) IBOutlet UIButton *button;

@property (nonatomic) NSString *text;
@end
