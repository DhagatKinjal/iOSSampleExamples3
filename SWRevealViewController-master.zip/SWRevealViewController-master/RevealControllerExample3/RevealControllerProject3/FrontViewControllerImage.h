//
//  FrontViewControllerBlocksViewController.h
//  RevealControllerProject3
//
//  Created by Joan on 30/12/12.
//
//

#import <UIKit/UIKit.h>

@interface FrontViewControllerImage : UIViewController

@property (nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic) IBOutlet UIButton *button;

@property (nonatomic) UIImage *image;

@end
