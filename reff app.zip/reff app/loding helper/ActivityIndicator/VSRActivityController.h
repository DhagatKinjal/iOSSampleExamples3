/*
 
 
 Copyright (c) DEEPAK KUAMR DASH
 
 
 */


#import <Foundation/Foundation.h>

@interface VSRActivityController : NSObject {

        UIWindow *window;
        NSString *text;
        UIButton *Btn;
        UIView *view;
        NSArray *animationArray;
}

@property (nonatomic, readonly) UIWindow *window;
+ (VSRActivityController *) makeText:(NSString *) _text;
- (void)show;
- (void)hide;

@end
