/*
 
 
 Copyright (c) DEEPAK KUAMR DASH
 
 
 */


#import "VSRActivityController.h"

@implementation VSRActivityController
@synthesize window;

- (id) init
{
	self = [super init];
	if (self != nil) {
		[[NSBundle mainBundle] loadNibNamed:@"VSRActivityIndicator" owner:self options:nil];
	}
	return self;
}


- (id) initWithText:(NSString *) tex{
	if (self = [super init]) {
		text = [tex copy];
	}
	
	return self;
}

- (void) show{
	[self show:1];
}

+ (VSRActivityController *) makeText:(NSString *) _text{
	VSRActivityController *VSRAct = [[VSRActivityController alloc] initWithText:_text];
	
	return VSRAct;
}

- (void)show:(NSInteger ) duration {
    
    animationArray =nil;
    animationArray=[NSArray arrayWithObjects:
                    [UIImage imageNamed:@"Layer 1.png"],
                    [UIImage imageNamed:@"Layer 2.png"],
                    [UIImage imageNamed:@"Layer 3.png"],
                    [UIImage imageNamed:@"Layer 4.png"],
                    [UIImage imageNamed:@"Layer 5.png"],
                    [UIImage imageNamed:@"Layer 6.png"],
                    [UIImage imageNamed:@"Layer 7.png"],
                    [UIImage imageNamed:@"Layer 8.png"],
                    [UIImage imageNamed:@"Layer 9.png"],
                    [UIImage imageNamed:@"Layer 10.png"],
                    [UIImage imageNamed:@"Layer 11.png"],
                    [UIImage imageNamed:@"Layer 12.png"],
                    [UIImage imageNamed:@"Layer 13.png"],
                    [UIImage imageNamed:@"Layer 14.png"],
                    [UIImage imageNamed:@"Layer 15.png"],
                    [UIImage imageNamed:@"Layer 16.png"],nil];
    
    window = [[[UIApplication sharedApplication] windows] objectAtIndex:0];
    
    view =[[UIView alloc] initWithFrame: CGRectMake (0, 0, 320, 586)];
    [view setTag:100001];
    [window addSubview:view];
    
    
    UIImageView *animationView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 10,30,30)];
    animationView.backgroundColor=[UIColor clearColor];
    animationView.animationImages=animationArray;
    animationView.animationDuration=2.8;
    animationView.animationRepeatCount=0;
    [animationView startAnimating];
    
    
    Btn = [UIButton buttonWithType:UIButtonTypeCustom];
    Btn.backgroundColor=[UIColor clearColor];
    Btn.layer.cornerRadius = 17;
    Btn.alpha=1;
    
    Btn.frame = CGRectMake(130, 270, 50,50);
    [Btn addSubview:animationView];
    
    UILabel *label2 = [[UILabel alloc] initWithFrame:CGRectMake(0, 110, 150, 40)];
	label2.backgroundColor = [UIColor clearColor];
	label2.textColor = [UIColor whiteColor];
    label2.textAlignment = NSTextAlignmentCenter;
	label2.font = [UIFont fontWithName:@"Georgia-Bold" size:15];
	//label2.text = @"Loading....";
	[Btn addSubview:label2];
    [view addSubview:Btn];
    
    
    
    
}

- (void)hide {
    
    [[[[[UIApplication sharedApplication] delegate] window] viewWithTag:100001] removeFromSuperview];
}
// #import "VSRActivityController.h"
//[[VSRActivityController makeText:@"WitVik"] show];
//[[VSRActivityController makeText:@"WitVik"] hide];

@end
