//
//  PHSessionView.h
//  PHAirTransaction
//
//  Created by Ta Phuoc Hai on 1/7/14.
//  Copyright (c) 2014 Phuoc Hai. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kHeaderTitleHeight   80

@interface PHSessionView : UIView

@property (nonatomic, strong) UIButton * button;
@property (nonatomic, strong) UIView   * containView;

@end
