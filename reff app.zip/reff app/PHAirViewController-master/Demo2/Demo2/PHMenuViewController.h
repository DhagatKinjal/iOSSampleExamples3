//
//  PHMenuViewController.h
//  Demo2
//
//  Created by Ta Phuoc Hai on 2/12/14.
//  Copyright (c) 2014 Phuoc Hai. All rights reserved.
//

#import "PHAirViewController.h"

@interface PHMenuViewController : PHAirViewController <PHAirMenuDataSource, PHAirMenuDelegate>

@end
