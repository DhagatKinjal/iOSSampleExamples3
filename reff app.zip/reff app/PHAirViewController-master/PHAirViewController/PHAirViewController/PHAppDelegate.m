//
//  PHAppDelegate.m
//  PHAirViewController
//
//  Created by Ta Phuoc Hai on 2/11/14.
//  Copyright (c) 2014 Phuoc Hai. All rights reserved.
//

#import "PHAppDelegate.h"

@implementation PHAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    return YES;
}

@end
