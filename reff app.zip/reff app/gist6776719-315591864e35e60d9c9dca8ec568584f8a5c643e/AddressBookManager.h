#import <Foundation/Foundation.h>
#import "Contact.h"

@interface AddressBookManager : NSObject

+ (NSString *)nameForContactWithPhoneNumber:(NSString *)phoneNumber;
+ (UIImage *)photoForContactWithPhoneNumber:(NSString *)phoneNumber;

@end
