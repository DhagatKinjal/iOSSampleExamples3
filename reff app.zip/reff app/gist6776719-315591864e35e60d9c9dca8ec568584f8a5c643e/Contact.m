#import "Contact.h"

@implementation Contact

@end