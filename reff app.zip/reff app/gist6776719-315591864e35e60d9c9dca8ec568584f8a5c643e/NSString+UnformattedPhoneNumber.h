#import <Foundation/Foundation.h>

@interface NSString (UnformattedPhoneNumber)

- (NSString *)unformattedPhoneNumber;

@end