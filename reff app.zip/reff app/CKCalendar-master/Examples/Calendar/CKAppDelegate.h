#import <UIKit/UIKit.h>

@class CKViewController;

@interface CKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CKViewController *viewController;

@end