//
//  KLCustomViewController.h
//  KLNoteViewController
//
//  Created by Kieran Lafferty on 2013-01-03.
//  Copyright (c) 2013 Kieran Lafferty. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KLCustomViewController : UIViewController
@property (nonatomic, strong) NSDictionary* info;
@end
