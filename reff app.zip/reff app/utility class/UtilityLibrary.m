//
//  UtilityLibrary.m
//  TestLibrary
//
//  Created on 12/4/13.
//

#import "UtilityLibrary.h"
#import "Reachability.h"
#import "Language.h"
#import <FacebookSDK/FacebookSDK.h>
#import "Constant.h"
#import  <CoreText/CoreText.h>
#define kInAppPurchaseProUpgradeProductId @"com.runmonster.runmonsterfree.upgradetopro"


@interface UtilityLibrary()
{
    
}
@property (nonatomic,copy) void(^getProducts)(NSArray * productIdentifiers);
@property (nonatomic,copy) void(^getData)(NSData * imageData, NSString * tag);
@property (nonatomic,retain) NSArray *arrayAvailableProducts;
@end

@implementation UtilityLibrary
@synthesize delegate,arrayAvailableProducts;
-(id)init
{
    if (!self)
    {
        self = [super init];
    }
    managerObject = [AFHTTPRequestOperationManager manager];
    return self;
}
-(void)cancelAllOperations
{
    [managerObject.operationQueue cancelAllOperations];
}

#pragma mark -
#pragma mark GET
-(void)getDataFromURL:(NSString *)str withParameters:(NSDictionary *)parameters andKey:(NSString *)key success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce
{
    NSString *strCheckConnection=[self CheckConnection]; // For checking internet connection
    if ([strCheckConnection isEqualToString:@"NO"])
        return;
    
    NSLog(@"kwy=%@",key);
    managerObject.responseSerializer = [AFHTTPResponseSerializer serializer];
    if (parameters!=nil)
    {
        NSData *data  = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
        NSString *jsonString = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
        NSString *requestString;
        if (key!=nil)
        {
            requestString = [NSString stringWithFormat:@"%@=%@",key,jsonString, nil];
        }
        else
        {
            requestString = [NSString stringWithFormat:@"%@",jsonString, nil];
        }
        NSString *urlstr = [NSString stringWithFormat:@"%@%@",str,requestString];
        urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        
        [managerObject GET:urlstr parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSData *responce = responseObject;
             id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
             successResponce(json);
             
         }failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             failureResponce(error);
         }];
    
    }
    else
    {
//        [managerObject GET:str parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject)
//         {
//             NSData *responce = responseObject;
//             id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
//             successResponce(json);
//             
//         }failure:^(AFHTTPRequestOperation *operation, NSError *error)
//         {
//             failureResponce(error);
//         }];
        
//        NSData *data  = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
//        NSString *jsonString = [[NSString alloc] initWithBytes:[data bytes] length:[data length] encoding:NSUTF8StringEncoding];
//        NSLog(@"%@",jsonString);
//        NSString *requestString;
//        if (key!=nil)
//        {
//            requestString = [NSString stringWithFormat:@"%@=%@",key,jsonString, nil];
//        }
//        else
//        {
//            requestString = [NSString stringWithFormat:@"%@",jsonString, nil];
//        }
        NSString *urlstr ;
        
        if (key)
        {
            NSString *requestString = [NSString stringWithFormat:@"%@",key, nil];
            urlstr = [NSString stringWithFormat:@"%@%@",str,requestString];
            urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

        }
        else
        {
            urlstr = [NSString stringWithFormat:@"%@",str];
            urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        }


        [managerObject GET:urlstr parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSData *responce = responseObject;
             id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
             successResponce(json);
             
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSString *strCheckConnection=[self CheckConnection]; // For checking internet connection
             if ([strCheckConnection isEqualToString:@"NO"])
                 return;
             else
                 failureResponce(error);
         }];
    }
}
#pragma mark -
#pragma mark POST

-(void)postDataWithURL:(NSString *)str withParameters:(NSDictionary *)parameters andKey:(NSString *)key success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce
{
    managerObject.responseSerializer = [AFHTTPResponseSerializer serializer];
//    NSString *urlstr = [NSString stringWithFormat:@"%@",str];
//    urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]; //NSASCIIStringEncoding
//    
    NSString *urlstr ;
    
    if (key)
    {
        NSString *requestString = [NSString stringWithFormat:@"%@",key, nil];
        urlstr = [NSString stringWithFormat:@"%@%@",str,requestString];
        urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
    }
    else
    {
        urlstr = [NSString stringWithFormat:@"%@",str];
        urlstr = [urlstr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }

    [managerObject POST:urlstr parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSData *responce = responseObject;
         
         id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
         successResponce(json);
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         failureResponce(error);
     }];
}
//-(void)postDataWithURL:(NSString *)str andParameters:(NSDictionary *)parameters success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce
//{
//    managerObject.responseSerializer = [AFHTTPResponseSerializer serializer];
//    [managerObject POST:str parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject)
//     {
//         NSData *responce = responseObject;
//         
//         id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
//         successResponce(json);
//
//    } failure:^(AFHTTPRequestOperation *operation, NSError *error)
//    {
//        failureResponce(error);
//    }];
//}

#pragma mark -
#pragma mark Download
-(void)downloadWithURL:(NSString *)str saveToPath:(NSString *)path success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce
{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:str];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response)
    {
        if (path != nil)
        {
            return [NSURL URLWithString:path];
        }
        else
        {
            NSURL *documentsDirectoryPath = [NSURL fileURLWithPath:[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject]];
            return [documentsDirectoryPath URLByAppendingPathComponent:[targetPath lastPathComponent]];
        }
        
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error)
    {
        NSLog(@"File downloaded to: %@", filePath);
        successResponce(filePath);
    }];
    [downloadTask resume];
}


#pragma mark -
#pragma mark UPLOAD
-(void)uploadWithURL:(NSString *)str andfilePath:(NSString *)path success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce
{
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    
    NSURL *URL = [NSURL URLWithString:[str stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
    NSURLRequest *request = [NSURLRequest requestWithURL:URL];
    
    NSURL *filePath = [NSURL fileURLWithPath:path];
    NSURLSessionUploadTask *uploadTask = [manager uploadTaskWithRequest:request fromFile:filePath progress:nil completionHandler:^(NSURLResponse *response, id responseObject, NSError *error) {
        if (error)
        {
            failureResponce(error);
        }
        else
        {
            successResponce(responseObject);
        }
    }];
    [uploadTask resume];
}


#pragma mark -
#pragma mark UPLOAD With Parameters
//@"dealImage"
-(void)uploadWithURL:(NSString *)str andfilePath:(NSString *)path andName:(NSString *)controlName andParameters:(NSDictionary *)parameters success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce
{
    managerObject.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSURL *filePath = [NSURL fileURLWithPath:[NSString stringWithFormat:@"%@",path]];

    [managerObject POST:str parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData> formData)
     {
        [formData appendPartWithFileURL:filePath name:controlName error:nil];
    } success:^(AFHTTPRequestOperation *operation, id responseObject)
    {
        NSData *responce = responseObject;
       
        id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
        successResponce(json);
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error)
    {
        failureResponce(error);
    }];
    
    

}





#pragma mark Alert showing
+(void)showAlertWithTitle:(NSString *)title message:(NSString *)messageString andButtonTitle:(NSString *)btnTitle
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:MyLocalizedString(title, title) message:MyLocalizedString(messageString, messageString) delegate:self cancelButtonTitle:MyLocalizedString(btnTitle, btnTitle) otherButtonTitles:nil, nil];
    [alert show];
   //   [alert performSelectorOnMainThread:@selector(show) withObject:nil waitUntilDone:YES];
}


//++++++++++++++++++++FACEBOOK POSTING++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++

#pragma mark -

#pragma mark posting on SinaWeibo
+(void)sendSinaWeiboPost:(NSString *)title withImage:(UIImage *)path addComposerToViewController:(UIViewController *)controller
{
    SLComposeViewController *mySLComposerSheet;
    {
        mySLComposerSheet = [[SLComposeViewController alloc] init]; //initiate the Social Controller
        mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeSinaWeibo]; //Tell him with what social plattform to use it, e.g. facebook or twitter

        if (mySLComposerSheet != nil)
        {
                       [mySLComposerSheet setInitialText:title]; //the message you want to post
            if (path)
            {
                [mySLComposerSheet addImage:path]; //an image you could post
            }
            [controller presentViewController:mySLComposerSheet animated:YES completion:nil];
        }
        else
        {
            [self showAlertWithTitle:@"" message:@"SinaWeibo app not available" andButtonTitle:@"OK"];
        }

    }
    [mySLComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result)
     {
         
         switch (result)
         {
             case SLComposeViewControllerResultCancelled:
                 //output = @"Action Cancelled";
                 break;
             case SLComposeViewControllerResultDone:
                 break;
             default:
                 break;
         } //check if everythink worked properly. Give out a message on the state.
         //         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
         //         [alert show];
     }];
}

+ (BOOL)isSocialAvailable
{
    static BOOL available;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        available = NSClassFromString(@"SLComposeViewController") != nil;
    });
    return available;
}
#pragma mark posting on facebook
+(void)sendFacebookPost:(NSString *)title withImage:(UIImage *)path addComposerToViewController:(UIViewController *)controller
{
    SLComposeViewController *mySLComposerSheet;
    {
        mySLComposerSheet = [[SLComposeViewController alloc] init]; //initiate the Social Controller
        mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook]; //Tell him with what social plattform to use it, e.g. facebook or twitter
        [mySLComposerSheet setInitialText:title]; //the message you want to post
        if (path)
        {
            [mySLComposerSheet addImage:path]; //an image you could post
        }
        
        //for more instance methodes, go here:https://developer.apple.com/library/ios/#documentation/NetworkingInternet/Reference/SLComposeViewController_Class/Reference/Reference.html#//apple_ref/doc/uid/TP40012205
        [controller presentViewController:mySLComposerSheet animated:YES completion:nil];
    }
    [mySLComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result)
     {
         
         switch (result)
         {
             case SLComposeViewControllerResultCancelled:
                 //output = @"Action Cancelled";
                 break;
             case SLComposeViewControllerResultDone:
                break;
             default:
                 break;
         } //check if everythink worked properly. Give out a message on the state.
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Facebook" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//         [alert show];
     }];
}



//++++++++++++++++++++Twitter POSTING++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++

#pragma mark -

#pragma mark tweeting on twitter
+(void)sendTwiterPost:(NSString *)title withImage:(UIImage *)path addComposerToViewController:(UIViewController *)controller
{
    SLComposeViewController *mySLComposerSheet;
    {
        mySLComposerSheet = [[SLComposeViewController alloc] init]; //initiate the Social Controller
        mySLComposerSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter]; //Tell him with what social plattform to use it, e.g. facebook or twitter
        [mySLComposerSheet setInitialText:title]; //the message you want to post
        if (path)
        {
            [mySLComposerSheet addImage:path]; //an image you could post
        }
        
        //for more instance methodes, go here:https://developer.apple.com/library/ios/#documentation/NetworkingInternet/Reference/SLComposeViewController_Class/Reference/Reference.html#//apple_ref/doc/uid/TP40012205
        [controller presentViewController:mySLComposerSheet animated:YES completion:nil];
    }
    [mySLComposerSheet setCompletionHandler:^(SLComposeViewControllerResult result)
     {
         switch (result)
         {
             case SLComposeViewControllerResultCancelled:
                 //output = @"Action Cancelled";
                 break;
             case SLComposeViewControllerResultDone:
                 break;
             default:
                 break;
         } //check if everythink worked properly. Give out a message on the state.
//         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Twitter" message:output delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
//         [alert show];
     }];
    
}

//https://graph.facebook.com/244587955553836/likes

-(void)liking:(ACAccount *)account
{
    
    managerObject.responseSerializer = [AFHTTPResponseSerializer serializer];
    NSDictionary *params = @{@"access_token" : account.credential.oauthToken};
    [managerObject POST:@"https://graph.facebook.com/244587955553836/likes" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject)
     {
        // NSData *responce = responseObject;
//         id json = [NSJSONSerialization JSONObjectWithData:responce options:NSJSONReadingAllowFragments error:nil];
         
         
     } failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"%@",error);
     }];
}
//-(void)SinaWeibo
//{
//    
//    ACAccountStore *accountStore = [[ACAccountStore alloc] init];
//    
//    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierSinaWeibo];
//    
//    [accountStore requestAccessToAccountsWithType:accountType options:nil completion:^(BOOL granted, NSError *error) {
//        
//        ACAccount *account = [[ACAccount alloc] initWithAccountType:accountType];
//        
//        NSLog(@"%@, %@", account.username, account.description);
//        
//    }];
//    
//    if([SLComposeViewController isAvailableForServiceType:SLServiceTypeSinaWeibo]) {
//        
//        SLComposeViewController *controller = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeSinaWeibo];
//        
//        SLComposeViewControllerCompletionHandler myBlock = ^(SLComposeViewControllerResult result){
//            
//            if (result == SLComposeViewControllerResultCancelled) {
//                
//                NSLog(@"Cancelled");
//                
//            } else
//                
//            {
//                
//                NSLog(@"Done");
//                
//            }
//            
//            [controller dismissViewControllerAnimated:YES completion:Nil];
//            
//        };
//        
//        controller.completionHandler =myBlock;
//        
//        [controller setInitialText:@"Test Post from mobile.safilsunny.com"];
//        
//        [controller addURL:[NSURL URLWithString:@"http://www.mobile.safilsunny.com"]];
//        
//        [controller addImage:[UIImage imageNamed:@"sw.png"]];
//        
//        
//    }
//    
//    else{
//        
//        NSLog(@"UnAvailable");
//        
//    }
//    
//}

//-(void)SinaWeibo
//{
//       ACAccountStore *facebookStore = [[ACAccountStore alloc] init];
//    ACAccountType *facebookAccountType = [facebookStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
//    
//    NSDictionary *options = @{
//                              @"ACFacebookAppIdKey" : @"2045436852",
//                              @"ACFacebookPermissionsKey" : @[@"publish_stream"],
//                              @"ACFacebookAudienceKey" : ACFacebookAudienceEveryone}; // Needed only when write permissions are requested
//    
//    [facebookStore requestAccessToAccountsWithType:facebookAccountType options:options
//                                            completion:^(BOOL granted, NSError *error) {
//                                                if (granted)
//                                                {
//                                                    NSArray *accounts = [facebookStore
//                                                                         accountsWithAccountType:facebookAccountType];
//                                                    NSArray *ar = [accounts lastObject];
//                                                } else {
//                                                    NSLog(@"%@",error);
//                                                    // Fail gracefully...
//                                                }
//                                            }];
//}

-(void)requestFacebookPermission:(NSString *)appKeyId withUserInfo:(BOOL)wantUserInfo ProfilePic:(BOOL)wantProfilePic andFriendlist:(BOOL)list success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce
{
    NSString *facebookAppId = appKeyId;
    
NSArray *facebookPermission = @[@"read_stream",@"email"];
  //   NSArray *facebookPermission = @[];
    
    NSDictionary *facebookOptions = @{ACFacebookAppIdKey : facebookAppId,
                                      ACFacebookPermissionsKey : facebookPermission,
                                      ACFacebookAudienceKey : ACFacebookAudienceFriends};
    
    ACAccountStore *facebookStore = [[ACAccountStore alloc] init];
    
    ACAccountType *facebookType = [facebookStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierFacebook];
    
    [facebookStore requestAccessToAccountsWithType:facebookType options:facebookOptions completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             
             NSArray *faceBookPermission = @[@"publish_actions"];
             
             NSDictionary *faceBookOptions = @{ACFacebookAppIdKey : facebookAppId,
                                               ACFacebookAudienceKey : ACFacebookAudienceFriends,
                                               ACFacebookPermissionsKey : faceBookPermission};
             
             [facebookStore requestAccessToAccountsWithType:facebookType options:faceBookOptions completion:^(BOOL grantedPublishing, NSError *error)
              {
                  
                  if (grantedPublishing)
                  {
                      
                      ACAccount *faceBookAccount = [[ACAccount alloc] initWithAccountType:facebookType];
                      
                      NSArray *arrayOfAccounts = [facebookStore accountsWithAccountType:facebookType];
                      
                      faceBookAccount = [arrayOfAccounts lastObject];
                      
                      if (list)
                      {
                          [self getFriendListWithSorting:YES account:faceBookAccount success:^(id response, NSString* tagstr)
                           {
                               successResponce(response,tagstr);
                           }failure:^(NSError *error)
                           {
                               failureResponce(error);
                           }];
                      }
                      
                      if (wantUserInfo)
                      {
                          NSURL *meurl = [NSURL URLWithString:@"https://graph.facebook.com/me"];
                          
                          SLRequest *merequest = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                                                    requestMethod:SLRequestMethodGET
                                                                              URL:meurl
                                                                       parameters:nil];
                          
                          merequest.account = faceBookAccount;
                          [merequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                           {
                               if (error == nil)
                               {
                                   //NSString *meDataString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
                                   
                                   NSMutableDictionary *dict = [[NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil] mutableCopy]; //[[meDataString JSONValue] mutableCopy];
                                   
                                   [dict setObject:faceBookAccount forKey:@"accountObject"];
                                   //                              / [self liking:faceBookAccount];
                                   
                                   if (wantProfilePic)
                                   {
                                       NSString *urlStringPic = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=normal",[NSString stringWithFormat:@"%@",[dict objectForKey:@"id"]]];
                                       //NSURL *meProfilePicurl = [NSURL URLWithString:urlStringPic];
                                       
                                       [dict setObject:urlStringPic forKey:@"fbuserPic"];
                                       
                                       //[delegate Responce:dict withRequestTag:@"facebook_userdetails" andInfodictionary:nil];
                                       successResponce(dict,@"facebook_userdetails");
                                       
                                       //                                   SLRequest *merequestPic = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                       //                                                                                requestMethod:SLRequestMethodGET
                                       //                                                                                          URL:meProfilePicurl
                                       //                                                                                   parameters:nil];
                                       //
                                       //                                   merequestPic.account = faceBookAccount;
                                       //                                   [merequestPic performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                                       //                                    {
                                       //                                        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
                                       //
                                       //                                        path = [NSString stringWithFormat:@"%@/facebookuserpic.jpeg",path];
                                       //
                                       //                                        [responseData writeToFile:path atomically:YES];
                                       //
                                       //                                        [dict setObject:path forKey:@"fbuserPic"];
                                       //
                                       //                                        [delegate Responce:dict withRequestTag:@"facebook_userdetails" andInfodictionary:nil];
                                       //                                    }];
                                       
                                       //[SLComposeViewController composeViewControllerForServiceType:SLServiceTypeSinaWeibo];
                                       
                                   }
                                   else
                                   {
                                       if ([dict objectForKey:@"error"] == nil)
                                       {
                                           //[delegate Responce:dict withRequestTag:@"facebook_userdetails" andInfodictionary:nil];
                                           successResponce(dict,@"facebook_userdetails");
                                       }
                                       else
                                       {
                                           if ([[NSString stringWithFormat:@"%@",[[dict objectForKey:@"error"] objectForKey:@"code"]] isEqualToString:@"190"])
                                           {
                                               [self renewingCredentialsWithaccount:facebookStore andAccountType:faceBookAccount wantUserInfo:wantUserInfo andPic:wantProfilePic success:^(id response, NSString *tgstr)
                                                {
                                                    successResponce(response,tgstr);
                                                }failure:^(NSError *error)
                                                {
                                                    failureResponce(error);
                                                }];
                                           }
                                       }
                                       
                                   }

                               }
                               else
                               {
                                  // [delegate errorOccured:error];
                                   failureResponce(error);
                               }
                               
                               
                           }];
                      }
                      else
                      {
                          //[delegate Responce:faceBookAccount withRequestTag:@"facebook_account" andInfodictionary:nil];
                          successResponce(faceBookAccount,@"facebook_account");
                      }
                      
                      
                  }
                  else if (!grantedPublishing)
                  {
                      NSLog(@"Publish permission error: %@", [error localizedDescription]);
                   //   failureResponce(error);
                      
                  }
                  
              }
              ];
             
             
         }
         
         else if (!granted)
         {
             NSLog(@"Read permission error: %@", [error localizedDescription]);
             if ([[error localizedDescription] isEqualToString:@"The operation couldn’t be completed. (com.apple.accounts error 6.)"])
             {
                 [self performSelectorOnMainThread:@selector(showError) withObject:error waitUntilDone:NO];
                 //[delegate errorOccured:nil];
                //   failureResponce(error);
             }
             failureResponce(error); 
             
         }
         
         
     }];
    
}
-(void)requestSinaWeiboPermission:(NSString *)appKeyId withUserInfo:(BOOL)wantUserInfo ProfilePic:(BOOL)wantProfilePic success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce
//-(void)SinaWeibo
{
//    ACAccountStore *strore  = [[ACAccountStore alloc] init];
//    ACAccountType *type = [strore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierSinaWeibo];
//    [strore requestAccessToAccountsWithType:type options:nil completion:^(BOOL granted, NSError *error)
//     {
//         if (granted)
//         {
//             NSArray *counts = [strore accountsWithAccountType:type];
//             NSLog(@"%@",counts.description);
////             if (counts && [counts count] > 0)
////             {
////                // [self requestWithAccount:[counts objectAtIndex:0]];
////             }
//         }
//     }];
    
    
    // Create an account store
    ACAccountStore *twitter = [[ACAccountStore alloc] init];
    
    // Create an account type
    ACAccountType *twAccountType = [twitter accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierSinaWeibo];
    
    // Request Access to the twitter account
    [twitter requestAccessToAccountsWithType:twAccountType options:nil completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             // Create an Account
             ACAccount *twAccount = [[ACAccount alloc] initWithAccountType:twAccountType];
             NSLog(@"%@",twAccount.username);
             NSArray *accounts = [twitter accountsWithAccountType:twAccountType];
             if ([accounts count]>0)
             {
                 twAccount = [accounts lastObject];
                 NSLog(@"%@",twAccount.accountDescription);
                 // Version 1.1 of the Twitter API only supports JSON responses.
                 // Create an NSURL instance variable that points to the home_timeline end point.
                 //             NSURL *twitterURL = [[NSURL alloc] initWithString:@"https://api.twitter.com/1.1/statuses/home_timeline.json"];
                 NSURL *twitterURL = [[NSURL alloc] initWithString:@"https://api.weibo.com/2/users/show.json"];
                 
                 
                 
                 // Version 1.0 of the Twiter API supports XML responses.
                 // Use this URL if you want to see an XML response.
                 //NSURL *twitterURL2 = [[NSURL alloc] initWithString:@"http://api.twitter.com/1/statuses/home_timeline.xml"];
                 
                 // NSDictionary *parameters=@{@"count":@"20"};
                 // Create a request
                 SLRequest *requestUsersTweets = [SLRequest requestForServiceType:SLServiceTypeSinaWeibo
                                                                    requestMethod:SLRequestMethodGET
                                                                              URL:twitterURL
                                                                       parameters:[NSDictionary dictionaryWithObject:twAccount.accountDescription forKey:@"screen_name"]];
                 
                 // Set the account to be used with the request
                 [requestUsersTweets setAccount:twAccount];
                 
                 // Perform the request
                 [requestUsersTweets performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error2)
                  {
                      if (error2)
                      {
                          failureResponce(error2);
                      }
                      else
                      {
                          // The output of the request is placed in the log.
                          NSLog(@"HTTP Response: %i", [urlResponse statusCode]);
                          // The output of the request is placed in the log.
                          NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
                          
                          NSLog(@"%@", jsonResponse);
                          
                          // [delegate Responce:jsonResponse withRequestTag:@"twitter" andInfodictionary:nil];
                          successResponce(jsonResponse,@"twitter");
                      }
                      
                      
                  }];
                 
                 
                 
                 // Tidy Up
                 twAccount = nil;
                 accounts = nil;
                 twitterURL = nil;
                 requestUsersTweets = nil;
             }
             else
             {
                 //                 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Twitter Account Required" message:@"You need to setup a twitter account within the Settings app." delegate:nil cancelButtonTitle:@"Ok." otherButtonTitles:nil, nil];
                 //                 [alert show];
                 //  alert = nil;
                 // [delegate errorOccured:nil];
                 failureResponce(error);
             }
         }
         
         // If permission is not granted to use the Twitter account...
         
         else
             
         {
             NSLog(@"Permission Not Granted");
             UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"SinaWeibo Account Error" message:@"Permission was not granted to this app." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
             [alert show];
             alert = nil;
             NSLog(@"Error: %@", error);
             //[delegate errorOccured:nil];
             failureResponce(error);
         }
     }];
    
    // Tidy up
    twitter = nil;
    twAccountType = nil;
    
}
- (void)requestWithAccount:(ACAccount *)account
{
    NSURL *url = [NSURL URLWithString:@"https://open.weibo.cn/2/statuses/update"];
    
    //配置参数字典
    NSDictionary *para = [NSDictionary dictionaryWithObjectsAndKeys:@"ssstext", @"status", nil];
    //配置轻取
    SLRequest *request = [SLRequest requestForServiceType:SLServiceTypeSinaWeibo requestMethod:SLRequestMethodGET URL:url parameters:para];
    //装载微博用户
    request.account = account;
    //发送微博
    [request performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
     {
         if (!error)
         {
             //主线程中操作UI
             dispatch_async(dispatch_get_main_queue(), ^{
                 NSString *response = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
                 NSLog(@"请求结果:%@",response);
                 //操作UI
             });
         }
     }];
}
-(void)requestTwitterPermission:(NSString *)appKeyId withUserInfo:(BOOL)wantUserInfo ProfilePic:(BOOL)wantProfilePic success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce
{
    // Create an account store
    ACAccountStore *twitter = [[ACAccountStore alloc] init];
    
    // Create an account type
    ACAccountType *twAccountType = [twitter accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    
    // Request Access to the twitter account
    [twitter requestAccessToAccountsWithType:twAccountType options:nil completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             // Create an Account
             ACAccount *twAccount = [[ACAccount alloc] initWithAccountType:twAccountType];
             NSArray *accounts = [twitter accountsWithAccountType:twAccountType];
             if ([accounts count]>0)
             {
             

             twAccount = [accounts lastObject];
             NSLog(@"%@",twAccount.username);
             // Version 1.1 of the Twitter API only supports JSON responses.
             // Create an NSURL instance variable that points to the home_timeline end point.
             //             NSURL *twitterURL = [[NSURL alloc] initWithString:@"https://api.twitter.com/1.1/statuses/home_timeline.json"];
             NSURL *twitterURL = [[NSURL alloc] initWithString:@"https://api.twitter.com/1.1/users/show.json"];
             
             
             
             // Version 1.0 of the Twiter API supports XML responses.
             // Use this URL if you want to see an XML response.
             //NSURL *twitterURL2 = [[NSURL alloc] initWithString:@"http://api.twitter.com/1/statuses/home_timeline.xml"];
             
             // Create a request
             SLRequest *requestUsersTweets = [SLRequest requestForServiceType:SLServiceTypeTwitter
                                                                requestMethod:SLRequestMethodGET
                                                                          URL:twitterURL
                                                                   parameters:[NSDictionary dictionaryWithObject:twAccount.username forKey:@"screen_name"]];
             
             // Set the account to be used with the request
             [requestUsersTweets setAccount:twAccount];
             
             // Perform the request
             [requestUsersTweets performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error2)
              {
                  if (error2)
                  {
                      failureResponce(error2);
                  }
                  else
                  {
                      // The output of the request is placed in the log.
                      NSLog(@"HTTP Response: %i", [urlResponse statusCode]);
                      // The output of the request is placed in the log.
                      NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
                      
                      NSLog(@"%@", jsonResponse);
                      
                     // [delegate Responce:jsonResponse withRequestTag:@"twitter" andInfodictionary:nil];
                      successResponce(jsonResponse,@"twitter");
                  }
                  
                  
              }];
             
            
         
             // Tidy Up
             twAccount = nil;
             accounts = nil;
             twitterURL = nil;
             requestUsersTweets = nil;
            }
             else
             {
//                 UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Twitter Account Required" message:@"You need to setup a twitter account within the Settings app." delegate:nil cancelButtonTitle:@"Ok." otherButtonTitles:nil, nil];
//                 [alert show];
               //  alert = nil;
                // [delegate errorOccured:nil];
                 failureResponce(error);
             }
         }
         
         // If permission is not granted to use the Twitter account...
         
         else
             
         {
             NSLog(@"Permission Not Granted");
             UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Twitter Account Error" message:@"Permission was not granted to this app." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
             [alert show];
            alert = nil;
             NSLog(@"Error: %@", error);
             //[delegate errorOccured:nil];
             failureResponce(error);
         }
     }];
    
    // Tidy up
    twitter = nil;
    twAccountType = nil;
}


-(void)showError
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Facebook Account Required" message:@"You need to setup a Facebook account within the Settings app." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    alert = nil;
}


-(void) renewingCredentialsWithaccount:(ACAccountStore *)accountStore andAccountType:(ACAccount *)faceBookAccount wantUserInfo:(BOOL)user andPic:(BOOL)picUser success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce
{
    if (faceBookAccount) {
        [accountStore renewCredentialsForAccount:faceBookAccount completion:^(ACAccountCredentialRenewResult renewResult, NSError *error)
         {
             
             switch (renewResult) {
                 case ACAccountCredentialRenewResultRenewed:
                 {
                     if (user)
                     {
                         NSURL *meurl = [NSURL URLWithString:@"https://graph.facebook.com/me"];
                         
                         SLRequest *merequest = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                                                   requestMethod:SLRequestMethodGET
                                                                             URL:meurl
                                                                      parameters:nil];
                         
                         merequest.account = faceBookAccount;
                         [merequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                          {
//                              NSString *meDataString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
                              
                              NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingAllowFragments error:nil];
                              
                              if (picUser)
                              {
                                  NSString *urlStringPic = [NSString stringWithFormat:@"https://graph.facebook.com/%@/picture",[NSString stringWithFormat:@"%@",[dict objectForKey:@"id"]]];
                                  NSURL *meProfilePicurl = [NSURL URLWithString:urlStringPic];
                                  
                                  
                                  SLRequest *merequestPic = [SLRequest requestForServiceType:SLServiceTypeFacebook
                                                                               requestMethod:SLRequestMethodGET
                                                                                         URL:meProfilePicurl
                                                                                  parameters:nil];
                                  
                                  merequestPic.account = faceBookAccount;
                                  [merequestPic performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                                   {
                                       NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
                                       
                                       path = [NSString stringWithFormat:@"%@/facebookuserpic.jpeg",path];
                                       
                                       [responseData writeToFile:path atomically:YES];
                                       
                                       [dict setObject:path forKey:@"fbuserPic"];
                                       
                                       //[delegate Responce:dict withRequestTag:@"facebook_userdetails" andInfodictionary:nil];
                                       successResponce(dict,@"facebook_userdetails");
                                   }];
                                  
                                  
                                  
                              }
                              else
                              {
                                  if ([dict objectForKey:@"error"] == nil)
                                  {
                                    //  [delegate Responce:dict withRequestTag:@"facebook_userdetails" andInfodictionary:nil];
                                      successResponce(dict,@"facebook_userdetails");
                                  }
                                  else
                                  {
                                      if ([[NSString stringWithFormat:@"%@",[[dict objectForKey:@"error"] objectForKey:@"code"]] isEqualToString:@"190"])
                                      {
                                          [self showError];
                                          [delegate errorOccured:nil];
                                          failureResponce(error);
                                      }
                                  }
                                  
                              }
                              
                              
                          }];
                     }
                 }break;
                 case ACAccountCredentialRenewResultFailed:
                 {
                     NSLog(@"Renewed Failed");
                 }break;
                 case ACAccountCredentialRenewResultRejected:
                 {
                     NSLog(@"Renewed Rejected");
                 }
                 default:
                     break;
             }
             
         }];
    }
}



#pragma mark -
#pragma mark get facebook friends list

-(void)getFriendListWithSorting:(BOOL)enableSort account:(ACAccount *)faceBookAccount success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce
{
    // Create the URL to the end point
    NSURL *friendsList = [NSURL URLWithString:@"https://graph.facebook.com/me/friends"];
    
    // Create the SLReqeust
    SLRequest *getFriends = [SLRequest requestForServiceType:SLServiceTypeFacebook requestMethod:SLRequestMethodGET URL:friendsList parameters:nil];
    
    
    getFriends.account = faceBookAccount;
    
    // Perform the request
    [getFriends performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
        if (error)
        {
            // If there is an error we populate the error string with error
            
            NSLog(@"Error: %@", [NSString stringWithFormat:@"%@", [error localizedDescription]]);
            failureResponce(error);
        } else
        {
            NSLog(@"HTTP Response: %i", [urlResponse statusCode]);
            // The output of the request is placed in the log.
            NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:nil];
           // [delegate Responce:jsonResponse withRequestTag:@"facebook_friendlist" andInfodictionary:nil];
            successResponce(jsonResponse,@"facebook_friendlist");
            // Tidy Up
            jsonResponse = nil;
        }
    }];
    
    // Tidy Up
    getFriends = nil;
    friendsList = nil;
}



//++++++++++++++++++++InApp Purchase++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++


#pragma mark getting product details

- (void)requestProductDataWithArray:(NSArray *)productsIdentifiers OnCompletion:(void (^)(NSArray *purchasableProducts))completionBlock;
{
    self.getProducts = completionBlock;
    NSSet *productIds = [NSSet setWithArray:productsIdentifiers];
    SKProductsRequest *productsRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:productIds];
    productsRequest.delegate = self;
    [productsRequest start];
}

-(SKProduct *)productForProductIdentifier:(NSString *)productIdentifier
{
    SKProduct *returnProduct = nil;
    for (SKProduct *product in arrayAvailableProducts)
    {
        if ([product.productIdentifier isEqualToString:productIdentifier])
        {
            returnProduct = product;
        }
    }
    return returnProduct;
}

- (NSString *)localizedPrice:(SKProduct *)product
{
    NSNumberFormatter *numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setFormatterBehavior:NSNumberFormatterBehavior10_4];
    [numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    [numberFormatter setLocale:product.priceLocale];
    NSString *formattedString = [numberFormatter stringFromNumber:product.price];
    return formattedString;
}


#pragma mark Store Coding

- (void)loadStore
{
    // restarts any purchases if they were interrupted last time the app was open
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
}


- (BOOL)canMakePurchases
{
    return [SKPaymentQueue canMakePayments];
}


-(BOOL) hasPurchasedProductIdentifier:(NSString *)productIdentifier
{
    return ([[NSUserDefaults standardUserDefaults] boolForKey:productIdentifier]);
}
//
// kick off the upgrade transaction
//
- (void)purchaseProUpgrade:(NSString *)productIdentifier;
{
    SKProduct *product = [self productForProductIdentifier:productIdentifier];
    SKPayment *payment = [SKPayment paymentWithProduct:product];
    [[SKPaymentQueue defaultQueue] addPayment:payment];
}

#pragma mark -
#pragma mark SKProductsRequestDelegate methods

- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
    //    NSArray *products = response.products;
    //    if ([products count]==1)
    //    {
    //        proUpgradeProduct = [[products firstObjectCommonWithArray:products] retain];
    //    }
    //    else
    //    {
    //        proUpgradeProduct = nil;
    //    }
    //
    //    if (proUpgradeProduct)
    //    {
    //        NSLog(@"Product title: %@" , proUpgradeProduct.localizedTitle);
    //        NSLog(@"Product description: %@" , proUpgradeProduct.localizedDescription);
    //        NSLog(@"Product price: %@" , proUpgradeProduct.price);
    //        NSLog(@"Product id: %@" , proUpgradeProduct.productIdentifier);
    //    }
    //
    //    for (NSString *invalidProductId in response.invalidProductIdentifiers)
    //    {
    //        NSLog(@"Invalid product id: %@" , invalidProductId);
    //    }
    //
    //    // finally release the reqest we alloc/init’ed in requestProUpgradeProductData
    //    [request release];
    //
    //    [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerProductsFetchedNotification object:self userInfo:nil];
    
    arrayAvailableProducts = response.products;
    self.getProducts(response.products);
    
}



#pragma mark -
#pragma mark Purchase helpers

//
// saves a record of the transaction by storing the receipt to disk
//
- (void)recordTransaction:(SKPaymentTransaction *)transaction
{
    if ([transaction.payment.productIdentifier isEqualToString:kInAppPurchaseProUpgradeProductId])
    {
        // save the transaction receipt to disk
        [[NSUserDefaults standardUserDefaults] setValue:transaction.transactionReceipt forKey:@"proUpgradeTransactionReceipt" ];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

//
// enable pro features
//
- (void)provideContent:(NSString *)purchasedProductID forTransaction:(SKPaymentTransaction *)transaction receiptData:(NSData *)receiptData
{
    
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:purchasedProductID];
    [[NSUserDefaults standardUserDefaults] synchronize];
    if ([purchasedProductID isEqualToString:kInAppPurchaseProUpgradeProductId])
    {
        // enable the pro features
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isProUpgradePurchased" ];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}

//
// removes the transaction from the queue and posts a notification with the transaction result
//
- (void)finishTransaction:(SKPaymentTransaction *)transaction wasSuccessful:(BOOL)wasSuccessful
{
    // remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
//    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:transaction, @"transaction" , nil];
    [delegate transactionResponce:wasSuccessful withTransactionObject:transaction];
}

//
// called when the transaction was successful
//
- (void)completeTransaction:(SKPaymentTransaction *)transaction
{
    [self recordTransaction:transaction];
    [self provideContent:transaction.payment.productIdentifier forTransaction:transaction receiptData:transaction.transactionReceipt];
    [self finishTransaction:transaction wasSuccessful:YES];
}

//
// called when a transaction has been restored and and successfully completed
//
- (void)restoreTransaction:(SKPaymentTransaction *)transaction
{
    [self recordTransaction:transaction.originalTransaction];
    [self provideContent:transaction.payment.productIdentifier forTransaction:transaction receiptData:transaction.transactionReceipt];
    [self finishTransaction:transaction wasSuccessful:YES];
}

//
// called when a transaction has failed
//
- (void)failedTransaction:(SKPaymentTransaction *)transaction
{
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        // error!
        [self finishTransaction:transaction wasSuccessful:NO];
    }
    else
    {
        // this is fine, the user just cancelled, so don’t notify
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    }
}

#pragma mark -
#pragma mark SKPaymentTransactionObserver methods

//
// called when the transaction status is updated
//
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
                break;
            default:
                break;
        }
    }
}

#pragma mark Other methods

-(void)drawText
{
    NSString* fileName = @"Invoice.PDF";
    
    NSArray *arrayPaths =
    NSSearchPathForDirectoriesInDomains(
                                        NSDocumentDirectory,
                                        NSUserDomainMask,
                                        YES);
    NSString *path = [arrayPaths objectAtIndex:0];
    NSString* pdfFileName = [path stringByAppendingPathComponent:fileName];
    
    NSString* textToDraw = @"Hello World";
    CFStringRef stringRef = (__bridge CFStringRef)textToDraw;
    
    // Prepare the text using a Core Text Framesetter.
    CFAttributedStringRef currentText = CFAttributedStringCreate(NULL, stringRef, NULL);
    CTFramesetterRef framesetter = CTFramesetterCreateWithAttributedString(currentText);
    
    CGRect frameRect = CGRectMake(0, 0, 300, 50);
    CGMutablePathRef framePath = CGPathCreateMutable();
    CGPathAddRect(framePath, NULL, frameRect);
    
    // Get the frame that will do the rendering.
    CFRange currentRange = CFRangeMake(0, 0);
    CTFrameRef frameRef = CTFramesetterCreateFrame(framesetter, currentRange, framePath, NULL);
    CGPathRelease(framePath);
    
    // Create the PDF context using the default page size of 612 x 792.
    UIGraphicsBeginPDFContextToFile(pdfFileName, CGRectZero, nil);
    
    // Mark the beginning of a new page.
    UIGraphicsBeginPDFPageWithInfo(CGRectMake(0, 0, 792, 612), nil);
    
    // Get the graphics context.
    CGContextRef currentContext = UIGraphicsGetCurrentContext();
    
    // Put the text matrix into a known state. This ensures
    // that no old scaling factors are left in place.
    CGContextSetTextMatrix(currentContext, CGAffineTransformIdentity);
    
    // Core Text draws from the bottom-left corner up, so flip
    // the current transform prior to drawing.
    CGContextTranslateCTM(currentContext, 0, 100);
    CGContextScaleCTM(currentContext, 1.0, -1.0);
    
    // Draw the frame.
    CTFrameDraw(frameRef, currentContext);
    
    CFRelease(frameRef);
    CFRelease(stringRef);
    CFRelease(framesetter);
    
    // Close the PDF context and write the contents out.
    UIGraphicsEndPDFContext();
    
}
-(void)createPDFfromUIView:(UIView*)aView saveToDocumentsWithFileName:(NSString*)aFilename
{
    // Creates a mutable data object for updating with binary data, like a byte array
    NSMutableData *pdfData = [NSMutableData data];
    
    // Points the pdf converter to the mutable data object and to the UIView to be converted
    UIGraphicsBeginPDFContextToData(pdfData, aView.bounds, nil);
    UIGraphicsBeginPDFPage();
    CGContextRef pdfContext = UIGraphicsGetCurrentContext();
    
    
    // draws rect to the view and thus this is captured by UIGraphicsBeginPDFContextToData
    
    [aView.layer renderInContext:pdfContext];
    
    // remove PDF rendering context
    UIGraphicsEndPDFContext();
    
    // Retrieves the document directories from the iOS device
    NSArray* documentDirectories = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask,YES);
    
    NSString* documentDirectory = [documentDirectories objectAtIndex:0];
    NSString* documentDirectoryFilename = [documentDirectory stringByAppendingPathComponent:aFilename];
    
    // instructs the mutable data object to write its context to a file on disk
    [pdfData writeToFile:documentDirectoryFilename atomically:YES];
    NSLog(@"documentDirectoryFileName: %@",documentDirectoryFilename);
}
-(NSString *)CheckConnection
{
    NSString *strReturn=@"";
    Reachability *r = [Reachability reachabilityWithHostName:@"www.google.com"];
    NetworkStatus internetStatus = [r currentReachabilityStatus];
    if ((internetStatus != ReachableViaWiFi) && (internetStatus != ReachableViaWWAN)){
        
        UIAlertView *myAlert = [[UIAlertView alloc]initWithTitle:@"No Internet Connection"message:@"You require an internet connection via WiFi or cellular network for location finding to work."
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                               otherButtonTitles:nil];
        
        [myAlert show];
        strReturn=@"NO";
    }
    else
    {
        strReturn=@"YES";
    }
    return strReturn;
}
- (BOOL) validateUrl: (NSString *) candidate
{
    if ([candidate isKindOfClass:[NSData class]])
        return NO;
    NSString *urlRegEx =    @"(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+";
    NSPredicate *urlTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", urlRegEx];
    return [urlTest evaluateWithObject:candidate];
}
- (BOOL)validateEmailWithString:(NSString*)email
{    
    NSString *emailRegex = @"(?:[a-z0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[a-z0-9!#$%\\&'*+/=?\\^_`{|}"
    @"~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\"
    @"x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-"
    @"z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5"
    @"]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-"
    @"9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21"
    @"-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}
- (BOOL)validateNumber:(NSString*)number
{
    NSString *emailRegex = @"^(?:[0-9]\\d*)(?:\\.\\d*)?$";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:number];
}
-(NSDictionary *)UploadImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData
{

    // get facebook profile pic
 //   NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"https://graph.facebook.com/%@/picture?type=large",user.id]]];
    UIImage *img = [UIImage imageWithData:data];
    
    // Create path.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"UserImage.png"];
    // save into documentdirectory
    [UIImagePNGRepresentation(img) writeToFile:filePath atomically:YES];
    
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    
   // NSString *postData = [NSString stringWithFormat:@"user_name=%@&user_password=%@&language_id=%@&ut_id=4&email_id=%@",user.id,@"",strLanguageId,strEmail_id]; //here
    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
   // [postbody appendData:[@"\r" dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"profile_photo\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data]];
    }
    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];

    return dict;
}

-(NSDictionary *)UploadProfileImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData
{
    UIImage *img = [UIImage imageWithData:data];
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    
    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"profile_photo\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data]];
    }
    
    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];
    
    return dict;
}
-(NSDictionary *)UploadBeneficiaryImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData
{
    UIImage *img = [UIImage imageWithData:data];
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    
    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data]];
    }
    
    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];
    
    return dict;
}



-(UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
    //UIGraphicsBeginImageContext(newSize);
    // In next line, pass 0.0 to use the current device's pixel scaling factor (and thus account for Retina resolution).
    // Pass 1.0 to force exact pixel size.
    UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
    [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}
-(NSDictionary *)UploadValuationImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData
{
    UIImage *img = [UIImage imageWithData:data];
    
    
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    
    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data]];
    }
    
    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];
    return dict;
}
-(NSDictionary *)UploadInsuranceImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData
{
    
    UIImage *img = [UIImage imageWithData:data];

    
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    
    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data]];
    }
    
    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];
    return dict;
}

-(NSDictionary *)UploadImageUrl:(NSString *)strUrl ImageData:(NSData *)data Front_Image:(NSData *)F_Data Back_Image:(NSData *)B_Data Left_Image:(NSData *)L_Data Right_Image:(NSData *)R_Data parameter:(NSString *)postData
{

    /*
     UIImage *img = [UIImage imageWithData:data];
    img = [self imageWithImage:img scaledToSize:CGSizeMake(320,480)];
    data = UIImagePNGRepresentation(img);
    // Create path.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *filePath = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"UserImage.png"];
    // save into documentdirectory
    [UIImagePNGRepresentation(img) writeToFile:filePath atomically:YES];
    
     UIImage *img1 = [UIImage imageWithData:F_Data];
    img1 = [self imageWithImage:img1 scaledToSize:CGSizeMake(320,480)];
    F_Data = UIImagePNGRepresentation(img1);
     UIImage *img2 = [UIImage imageWithData:B_Data];
    img2 = [self imageWithImage:img2 scaledToSize:CGSizeMake(320,480)];
    B_Data = UIImagePNGRepresentation(img2);
    
     UIImage *img3 = [UIImage imageWithData:L_Data];
    
    img3 = [self imageWithImage:img3 scaledToSize:CGSizeMake(320,480)];
    L_Data = UIImagePNGRepresentation(img3);

     UIImage *img4 = [UIImage imageWithData:R_Data];
    img4 = [self imageWithImage:img4 scaledToSize:CGSizeMake(320,480)];
    R_Data = UIImagePNGRepresentation(img4);
     */
    
    UIImage *img = [UIImage imageWithData:data];
  //  img = [self imageWithImage:img scaledToSize:CGSizeMake(320,480)];
   // data = UIImagePNGRepresentation(img);
    UIImage *img1 = [UIImage imageWithData:F_Data];
    UIImage *img2 = [UIImage imageWithData:B_Data];
  //  UIImage *img3 = [UIImage imageWithData:L_Data];
//    UIImage *img4 = [UIImage imageWithData:R_Data];
    
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];

    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"c_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data]];
    }
    //
    if(img1 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"f_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:F_Data]];
    }
    if(img2 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"b_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:B_Data]];
    }
//    if(img3 != nil)
//    {
//        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
//        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"l_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
//        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
//        [postbody appendData:[NSData dataWithData:L_Data]];
//    }
//    if(img4 != nil)
//    {
//        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
//        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"r_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
//        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
//        [postbody appendData:[NSData dataWithData:R_Data]];
//    }
    //

    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];
    
    return dict;
}

-(NSDictionary *)UploadSpecificImageUrl:(NSString *)strUrl Img_OriginalBill:(NSData *)data1 Img_authentication:(NSData *)data2 Img_Condition:(NSData *)data3 Img_Coin_Observe:(NSData *)data4 Img_Coin_Reverse:(NSData *)data5 Img_Automobile:(NSData *)data6 Img_Property:(NSData *)data7 parameter:(NSString *)postData
{
    UIImage *img =  [UIImage imageWithData:data1];
    UIImage *img1 = [UIImage imageWithData:data2];
    UIImage *img2 = [UIImage imageWithData:data3];
    UIImage *img3 = [UIImage imageWithData:data4];
    UIImage *img4 = [UIImage imageWithData:data5];
    UIImage *img5 = [UIImage imageWithData:data6];
    UIImage *img6 = [UIImage imageWithData:data7];
    
    // setting up the URL to post to
    NSURL *url = [[NSURL alloc]initWithString:strUrl];
    NSString *filename = @"image";
    NSMutableURLRequest *request= [[NSMutableURLRequest alloc] initWithURL:url] ;
    [request setURL:url];
    [request setHTTPMethod:@"POST"];
    NSString *boundary = @"---------------------------14737809831466499882746641449";
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",boundary];
    [request addValue:contentType forHTTPHeaderField: @"Content-Type"];
    NSMutableData *postbody = [NSMutableData data];
    
    postData = [postData stringByReplacingOccurrencesOfString:@"\r" withString:@""];
    NSLog(@"%@",postData);
    [postbody appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"parameter2\"\r\n\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    [postbody appendData:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    
    if(img != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image_original_bill\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data1]];
    }
    //
    if(img1 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image_authentication\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data2]];
    }
    if(img2 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"image_condition\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data3]];
    }
    if(img3 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"coin_observe_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data4]];
    }
    if(img4 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"coin_reverse_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data5]];
    }
    if(img5 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"ama_reg_cer_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data6]];
    }
    if(img6 != nil)
    {
        [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[[NSString stringWithFormat:@"Content-Disposition: form-data; name=\"property_own_cer_image\"; filetype=\"image/jpeg\"; filename=\"%@.jpg\"\r\n", filename] dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[@"Content-Type: image/jpeg\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [postbody appendData:[NSData dataWithData:data7]];
    }
    
    [postbody appendData:[[NSString stringWithFormat:@"\r\n--%@--\r\n",boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [request setHTTPBody:postbody];
    // now lets make the connection to the web
    NSData *returnData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    
    NSString *returnString = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    returnString =[returnString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    NSLog(@"response:==%@",returnString);
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:returnData options:NSJSONReadingMutableLeaves|| NSJSONReadingMutableContainers error:nil];
    
    return dict;
}



//save images in document dictionary
-(void)cachingImage:(UIImage *)imageThumb andString:(NSString *)str
{
    str = [str stringByReplacingOccurrencesOfString:@"/" withString:@"#"];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0]; //Get the docs directory
    NSString *filePath1 = [documentsPath stringByAppendingPathComponent:str]; //Add the file name
    NSData *pngData = UIImagePNGRepresentation(imageThumb);
    
    //    UIImage *img = [util imageWithImage:imageThumb scaledToSize:CGSizeMake(320,480)];
    //    NSData *pngData = UIImagePNGRepresentation(img);
    
    [pngData writeToFile:filePath1 atomically:YES];
}
//checking image exists of that name
-(BOOL)checkImageExists:(NSString *)str
{
    NSString* documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    str = [str stringByReplacingOccurrencesOfString:@"/" withString:@"#"];
    NSString* foofile = [documentsPath stringByAppendingPathComponent:str];
    BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:foofile];
    return fileExists;
}
//get path of cached image
-(NSString *)getPathOfCachedImage:(NSString *)str
{
    NSString* documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    str = [str stringByReplacingOccurrencesOfString:@"/" withString:@"#"];
    NSString* foofile = [documentsPath stringByAppendingPathComponent:str];
    return foofile;
}
// set image oriantation
- (UIImage *)fixrotation:(UIImage *)image
{
    if (image.imageOrientation == UIImageOrientationUp) return image;
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (image.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, image.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, image.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }    
    switch (image.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, image.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, image.size.width, image.size.height,
                                             CGImageGetBitsPerComponent(image.CGImage), 0,
                                             CGImageGetColorSpace(image.CGImage),
                                             CGImageGetBitmapInfo(image.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (image.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.height,image.size.width), image.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,image.size.width,image.size.height), image.CGImage);
            break;
    }
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

-(NSString *)Remove_Null_From_String:(NSString *)str
{
    NSString *strResult = nil;
    NSObject *obj = str;
    if ([obj isKindOfClass:[NSNull class]] || [str isEqualToString:@"(null)"])
    {
        strResult = @"";
    }
    else
    {
        strResult =str;
    }
    return strResult;
}
-(NSString *)Remove_Zero_Date_From_String:(NSString *)str
{
    NSString *strResult = nil;
    if ([str isEqualToString:@"0000-00-00"] || [str isEqualToString:@"0000-00-00 00:00:00"] || [str isEqualToString:@"0000"])
    {
        strResult = @"";
    }
    else
    {
        strResult =str;
    }
    return strResult;
}
-(CGFloat)HeightOfNiDropDownList:(NSMutableArray *)arr
{
    CGFloat H = 0.0;
    
    if ([arr count]>4)
    {
        if (IS_IPHONE)
            H = 160;
        else
            H = 320;
    }
    else
    {
        if (IS_IPHONE)
            H = [arr count] * 40;
        else
            H = [arr count] * 80;
    }
    return H;
}
#pragma SlideMenu Delegate

-(void)show:(UIView *)SideView CurrentView:(UIView *)SelfView
{
    SideView.hidden = FALSE;
//    [UIView setAnimationDelegate:self];
//    
//    [UIView animateWithDuration:0.5 animations:^{
//        [SideView setFrame:CGRectMake(SideView.frame.origin.x-160, SideView.frame.origin.y, SideView.frame.size.width, SideView.frame.size.height)];
//    [SelfView setFrame:CGRectMake(SelfView.frame.origin.x, SelfView.frame.origin.y, SelfView.frame.size.width, SelfView.frame.size.height)];
//    }];
//    [UIView commitAnimations];

    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
                         //animation block
                         if (IS_IPHONE)
                             [SideView setFrame:CGRectMake(SideView.frame.origin.x-320, SideView.frame.origin.y, SideView.frame.size.width, SideView.frame.size.height)];
                         else
                             [SideView setFrame:CGRectMake(SideView.frame.origin.x-768, SideView.frame.origin.y, SideView.frame.size.width, SideView.frame.size.height)];
                     }
                     completion:^(BOOL finished){//this block starts only when
                         //the animation in the upper block ends
                         //so you know when exactly the animation ends
                         
                     }];

}
-(void)hide:(UIView *)SideView CurrentView:(UIView *)SelfView
{
   //   SideView.hidden = TRUE;
//    [UIView setAnimationDelegate:self];
//    
//    [UIView animateWithDuration:0.5 animations:^{
//        [SideView setFrame:CGRectMake(SideView.frame.origin.x+160, SideView.frame.origin.y, SideView.frame.size.width, SideView.frame.size.height)];
//        [SelfView setFrame:CGRectMake(SelfView.frame.origin.x, SelfView.frame.origin.y, SelfView.frame.size.width, SelfView.frame.size.height)];
//    }];
//    [UIView commitAnimations];
    
    [UIView animateWithDuration:0.5
                          delay:0.0
                        options:UIViewAnimationOptionBeginFromCurrentState
                     animations:^{
                         //animation block
                         if (IS_IPHONE)
                             [SideView setFrame:CGRectMake(320, SideView.frame.origin.y, SideView.frame.size.width, SideView.frame.size.height)];
                         else
                             [SideView setFrame:CGRectMake(768, SideView.frame.origin.y, SideView.frame.size.width, SideView.frame.size.height)];
                     }
                     completion:^(BOOL finished)
     {
         //this block starts only when
         //the animation in the upper block ends
         //so you know when exactly the animation ends
         
     }];
}

- (NSString*)reverseString:(NSString*)string
{
    NSMutableString *reversedString;
    int length     = [string length];
    reversedString = [NSMutableString stringWithCapacity:length];
    while (length--)
    {
        [reversedString appendFormat:@"%C", [string   characterAtIndex:length]];
    }
    return reversedString;
}

/*
 
 #pragma mark -FB Sharing Delegate Method
 // A function for parsing URL parameters returned by the Feed Dialog.
 - (NSDictionary*)parseURLParams:(NSString *)query
 {
 NSArray *pairs = [query componentsSeparatedByString:@"&"];
 NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
 for (NSString *pair in pairs) {
 NSArray *kv = [pair componentsSeparatedByString:@"="];
 NSString *val =
 [kv[1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
 params[kv[0]] = val;
 }
 return params;
 }
 -(IBAction)btn_Facebook_Clicked:(id)sender
 {
 FBShareDialogParams *params = [[FBShareDialogParams alloc] init];
 
 
 params.picture = [NSURL URLWithString:@"http://dev.credencys.com/bottomsup/images/app_icon.png"];
 params.name = @"testing";
 //  params.description=@"Check it out on Bottoms Up!";
 params.caption=@"hiii testing";
 params.link = [NSURL URLWithString:@"http://www.google.com/"];
 
 
 // If the Facebook app is installed and we can present the share dialog
 if ([FBDialogs canPresentShareDialogWithParams:params])
 {
 // Present share dialog
 [FBDialogs presentShareDialogWithLink:params.link name:params.name caption:params.caption description:params.description picture:params.picture clientState:nil handler:^(FBAppCall *call, NSDictionary *results, NSError *error)
 {
 if(error)
 {
 UIAlertView *alertView = [[UIAlertView alloc]
 initWithTitle:@"Sorry"
 message:@"There might be some Error with connection so please try again Later!!"
 delegate:nil
 cancelButtonTitle:@"OK"
 otherButtonTitles:nil];
 [alertView show];
 
 }
 }];
 
 // If the Facebook app is NOT installed and we can't present the share dialog
 }
 else
 {
 NSMutableDictionary *params;
 
 params= [NSMutableDictionary dictionaryWithObjectsAndKeys:@"http://dev.credencys.com/bottomsup/images/app_icon.png",@"picture",@"testing",@"name",@"hii testing", @"caption",@"http://www.google.com/",@"link",nil];
 
 [FBWebDialogs presentFeedDialogModallyWithSession:nil parameters:params handler:^(FBWebDialogResult result, NSURL *resultURL, NSError *error)
 {
 if (error)
 {
 
 UIAlertView *alertView = [[UIAlertView alloc]
 initWithTitle:@"Sorry"
 message:@"There might be some Error with connection so please try again Later!!"
 delegate:nil
 cancelButtonTitle:@"OK"
 otherButtonTitles:nil];
 [alertView show];
 }
 else
 {
 if (result == FBWebDialogResultDialogNotCompleted)
 {
 // User canceled.
 NSLog(@"User cancelled.");
 }
 else
 {
 
 NSDictionary *urlParams = [self parseURLParams:[resultURL query]];
 
 if (![urlParams valueForKey:@"post_id"])
 {
 // User canceled.
 NSLog(@"User cancelled.");
 
 }
 else
 {
 // User clicked the Share button
 NSString *result = [NSString stringWithFormat: @"Posted story, id: %@", [urlParams valueForKey:@"post_id"]];
 NSLog(@"result %@", result);
 }
 }
 }
 }];
 
 }
 }

 
 
 */







/*
 //    NSString *ver = [[UIDevice currentDevice] systemVersion];
 //    int ver_int = [ver intValue];
 //    if (ver_int < 7)
 //        [self.navigationController.navigationBar setTintColor:[UIColor blackColor]];
 //    else
 //        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
 */
@end
