//
//  UtilityLibrary.h
//  TestLibrary
//
//  Created on 12/4/13.
//

#import <Foundation/Foundation.h>
#import "AFHTTPRequestOperationManager.h"
#import "AFURLSessionManager.h"
#import <Social/Social.h>
#import <Accounts/Accounts.h>
#import <StoreKit/StoreKit.h>

#define kInAppPurchaseManagerProductsFetchedNotification @"kInAppPurchaseManagerProductsFetchedNotification"

#define kInAppPurchaseManagerTransactionFailedNotification @"kInAppPurchaseManagerTransactionFailedNotification"
#define kInAppPurchaseManagerTransactionSucceededNotification @"kInAppPurchaseManagerTransactionSucceededNotification"

// define the protocol for the delegate
@protocol UitilitiesLibraryDelegate

// define protocol functions that can be used in any class using this delegate

//use when fetchingDatafromURL & fetchingDataOnlyfromURL function is used
-(void)Responce:(id)collection withRequestTag:(NSString *)tagStr andInfodictionary:(NSDictionary *)dict;
-(void)errorOccured:(NSError *)error;
-(void)transactionResponce:(BOOL)result withTransactionObject:(SKPaymentTransaction *)transaction;

@end




@interface UtilityLibrary : NSObject <SKProductsRequestDelegate,SKPaymentTransactionObserver>
{
    AFHTTPRequestOperationManager *managerObject;
}

// cancels all the operation of afnetworking.
-(void)cancelAllOperations;

-(void)getDataFromURL:(NSString *)str withParameters:(NSDictionary *)parameters andKey:(NSString *)key success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce;
-(void)postDataWithURL:(NSString *)str withParameters:(NSDictionary *)parameters andKey:(NSString *)key success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce;
-(void)postDataWithURL:(NSString *)str andParameters:(NSDictionary *)parameters success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce;
-(void)downloadWithURL:(NSString *)str saveToPath:(NSString *)path success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce;
-(void)uploadWithURL:(NSString *)str andfilePath:(NSString *)path andName:(NSString *)controlName andParameters:(NSDictionary *)parameters success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce;
-(void)uploadWithURL:(NSString *)str andfilePath:(NSString *)path andParameters:(NSDictionary *)parameters success:(void(^)(id responce))successResponce failure:(void(^)(NSError *error))failureResponce;
-(NSDictionary *)UploadBeneficiaryImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData;
@property (nonatomic,assign) id delegate;

//-(void)SinaWeibo;

//Showing Simple Alert
+(void)showAlertWithTitle:(NSString *)title message:(NSString *)messageString andButtonTitle:(NSString *)btnTitle;

//Posting On SinaWeibo
+(void)sendSinaWeiboPost:(NSString *)title withImage:(UIImage *)path addComposerToViewController:(UIViewController *)controller;

//Posting On Facebook
+(void)sendFacebookPost:(NSString *)title withImage:(UIImage *)path addComposerToViewController:(UIViewController *)controller;

//Posting On Twitter
+(void)sendTwiterPost:(NSString *)title withImage:(UIImage *)path addComposerToViewController:(UIViewController *)controller;

-(void)requestSinaWeiboPermission:(NSString *)appKeyId withUserInfo:(BOOL)wantUserInfo ProfilePic:(BOOL)wantProfilePic success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce;

//Getting facebook permission, user info and pic
-(void)requestFacebookPermission:(NSString *)appKeyId withUserInfo:(BOOL)wantUserInfo ProfilePic:(BOOL)wantProfilePic andFriendlist:(BOOL)list success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce;


-(void)requestTwitterPermission:(NSString *)appKeyId withUserInfo:(BOOL)wantUserInfo ProfilePic:(BOOL)wantProfilePic success:(void(^)(id responce, NSString *tagstr))successResponce failure:(void(^)(NSError *error))failureResponce;

//Getting list of facebook friends
-(void)getFriendListWithSorting:(BOOL)enableSort account:(ACAccount *)faceBookAccount;
+ (BOOL)isSocialAvailable;
// sharing on facebook using facebook SDK

-(NSDictionary *)Call_ViewPdf_Webservice:(NSString *)strCl_Id;
-(void)drawText;
- (void)loadStore;
- (BOOL)canMakePurchases;
-(BOOL) hasPurchasedProductIdentifier:(NSString *)productIdentifier;
- (void)purchaseProUpgrade:(NSString *)productIdentifier;
- (NSString *)localizedPrice:(SKProduct *)product;
- (void)requestProductDataWithArray:(NSArray *)productsIdentifiers OnCompletion:(void (^)(NSArray *purchasableProducts))completionBlock;
-(SKProduct *)productForProductIdentifier:(NSString *)productIdentifier;
-(NSString *)CheckConnection;
- (BOOL) validateUrl: (NSString *) candidate;
- (BOOL)validateEmailWithString:(NSString*)email;
- (BOOL)validateNumber:(NSString*)email;
-(NSDictionary *)UploadValuationImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData;
-(NSDictionary *)UploadProfileImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData;
-(NSDictionary *)UploadInsuranceImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData;
-(NSDictionary *)UploadSpecificImageUrl:(NSString *)strUrl Img_OriginalBill:(NSData *)data Img_authentication:(NSData *)F_Data Img_Condition:(NSData *)B_Data Img_Coin_Observe:(NSData *)L_Data Img_Coin_Reverse:(NSData *)R_Data Img_Automobile:(NSData *)R_Data Img_Property:(NSData *)R_Data parameter:(NSString *)postData;
-(NSDictionary *)UploadImageUrl:(NSString *)strUrl ImageData:(NSData *)data parameter:(NSString *)postData;
-(NSDictionary *)UploadImageUrl:(NSString *)strUrl ImageData:(NSData *)data Front_Image:(NSData *)F_Data Back_Image:(NSData *)B_Data Left_Image:(NSData *)L_Data Right_Image:(NSData *)R_Data parameter:(NSString *)postData;
-(UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;
//save images in document dictionary
-(void)cachingImage:(UIImage *)imageThumb andString:(NSString *)str;
//checking image exists of that name
-(BOOL)checkImageExists:(NSString *)str;
//get path of cached image
-(NSString *)getPathOfCachedImage:(NSString *)str;
// set Image orientation
- (UIImage *)fixrotation:(UIImage *)image;
-(NSString *)Remove_Null_From_String:(NSString *)str;
-(void)show:(UIView *)SideView CurrentView:(UIView *)SelfView;
-(void)hide:(UIView *)SideView CurrentView:(UIView *)SelfView;
- (NSString*)reverseString:(NSString*)string;
-(NSString *)Remove_Zero_Date_From_String:(NSString *)str;
-(CGFloat)HeightOfNiDropDownList:(NSMutableArray *)arr;
//-(void)LogOutFromApp;
@end
